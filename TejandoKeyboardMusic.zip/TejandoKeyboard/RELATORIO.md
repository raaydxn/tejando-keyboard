# Tejando Keyboard Music — Relatório final (versão 0.2.0)

## Estado honesto
- **O APK NÃO foi compilado nem testado em aparelho.** O ambiente de desenvolvimento não tinha Android SDK, Gradle nem internet.
- O código passou por revisão estática (balanceamento de chaves, símbolos referenciados, imports, assinaturas). Isso NÃO substitui o compilador: podem existir erros de compilação.
- Há um fluxo do GitHub Actions (`.github/workflows/build-apk.yml`) que compila e entrega o APK como artefato. Se falhar, o log aponta o erro exato.
- Verificado de fato: a versão web de teste (mesmas receitas e mapa de teclas) teve a sintaxe do JavaScript checada. Nenhum áudio foi ouvido nem medido.

## Arquivos recebidos
- TejandoKeyboard.zip: base (código-fonte; **não continha APK**, e o teclado não tinha nenhum áudio, causa de não haver notas).
- grok-workspace.zip: app web com sintetizador Web Audio (`sound-engine.ts`, `music.ts`, `studio.tsx`), sem samples, sem MIDI. Receitas de bateria, efeitos e escalas foram portadas para Kotlin.
- florisboard-main.zip, AnySoftKeyboard-main.zip: inspecionados, nenhum código copiado.

## Funcionalidades implementadas (no código)
- QWERTY musical integrado: toda letra insere texto E toca nota (no instante do toque).
- Mapeamento tecla→grau da escala, 7 escalas, tônica, oitava; números/pontuação/espaço com instrumentos próprios.
- Motor de áudio próprio (AudioTrack baixa latência, 24 vozes, eco, reverb, drive, filtro): piano, guitarra, baixo, pluck, 4 synths, bateria de 15 peças.
- Bateria junto (espaço=bumbo, vogais=chimbal, pontuação=caixa) e clique mecânico opcional.
- Mixer na aba `!#1`, botão MIX ao lado da vírgula, com controles reais; mudo, restaurar, testar; salvo localmente.
- Linha numérica permanente; Shift/Caps Lock (toque duplo 500 ms, estado visual).
- Altura, espaçamento, largura (modo uma mão), tamanho das teclas de função.
- Sugestões locais (lista pt-BR, ignora acento, correção a 1 edição, vocabulário aprendido, pontuação).
- Corrigir local (espaços e maiúsculas); IA: corrigir, traduzir, reescrever, resumir, organizar, explicar, continuar, com prévia antes de aplicar; só o trecho selecionado (ou a última linha).
- Provedor de IA modular (interface `AiProvider`; um provedor "OpenAI/compatível" pronto), chave cifrada no Keystore.
- Emojis (6 categorias, recentes), área de transferência (histórico, fixar, apagar), cursor deslizando na barra de espaço, desfazer/refazer/selecionar/copiar/cortar/colar.
- Cofre de senhas protegido por digital (Keystore, autenticação a cada uso).
- Configurações por categoria e tela de testes no aparelho (áudio medido, toques simulados).

## Testes (tela "Testes e diagnóstico")
Escritos mas **ainda não executados**. Ao rodar, cada um mostra PASSOU / FALHOU / NÃO EXECUTADO. Mede: energia e frequência das notas, bateria, efeito do mixer no sinal, oitava, mapeamento, AudioTrack recebendo amostras, rajada de toques, números/letras/Shift/Caps/Enter/Backspace por toques simulados, MIX ao lado da vírgula, emojis, redimensionamento, persistência, sugestões, correção, área de transferência, criptografia. Não executáveis automaticamente: audibilidade/latência percebida, digital do cofre, internet/IA/tradução.

## Dependências
androidx core-ktx, activity-ktx, exifinterface, fragment, biometric. Sem bibliotecas de áudio de terceiros. Permissões: INTERNET (IA/tradução, sob toque) e USE_BIOMETRIC (cofre).

## Exigem API/chave/internet
Tradução e todas as ações de IA. Assinatura do ChatGPT/Gemini NÃO dá acesso à API (conta separada, com cobrança). Gemini e Claude usam protocolos próprios: precisam de um novo provedor em `ai/Ai.kt`.

## Limitações conhecidas
- Não implementados: ditado por voz, GIFs, modo flutuante, busca de emojis, tradução offline, mapeamento tecla a tecla editável, Autofill, notas salvas.
- Emojis: lista curada fixa (sem atualização automática).
- Latência real varia por aparelho; não medida em hardware. Sem samples: timbres sintetizados (soam mais "sintéticos" que instrumentos gravados).
- Cofre: se a digital do aparelho mudar, o Android invalida a chave e os itens precisam ser recriados. Teclado não pode mostrar a digital sobre outro app, por isso abre uma tela do cofre.
- Histórico de cópia: o Android só entrega a área de transferência ao teclado ativo em foco.
- O `applicationId` continua `com.tejando.keyboard` para não quebrar instalações anteriores.

## Problemas corrigidos
Teclado sem áudio (motor novo); linha numérica era só dica sobre as letras (agora fileira própria); Caps Lock falhava com auto-maiúscula e janela de 350 ms (agora 500 ms e tratado); nome do app.

## Como compilar
GitHub Actions (suba a pasta, baixe o artefato `app-debug.apk`) ou Android Studio (Open, aguardar Gradle 8.7, Build APK). O `gradlew` não vem no ZIP: `gradle wrapper --gradle-version 8.7`.

## Verificação do nome
"Tejando Keyboard Music" confirmado em: `app_name`, `ime_name` (launcher e seletor de teclado), `rootProject.name`, README, textos de ativação. Nenhuma variante encontrada.
