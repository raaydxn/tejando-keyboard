package com.tejando.keyboard

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import com.tejando.keyboard.ai.AiAction
import com.tejando.keyboard.ai.AiResult
import com.tejando.keyboard.ai.AiRunner
import com.tejando.keyboard.ai.TRANSLATE_LANGS
import com.tejando.keyboard.audio.Drum
import com.tejando.keyboard.audio.Instrument
import com.tejando.keyboard.audio.KeyMap
import com.tejando.keyboard.audio.KeySounds
import com.tejando.keyboard.audio.MixerState
import com.tejando.keyboard.audio.MixerStore
import com.tejando.keyboard.audio.SoundEngine
import com.tejando.keyboard.data.ClipboardStore
import com.tejando.keyboard.data.KeyboardPrefs
import com.tejando.keyboard.data.WallpaperStore
import com.tejando.keyboard.engine.LocalFixer
import com.tejando.keyboard.engine.LocalSuggestionEngine
import com.tejando.keyboard.engine.currentWordPrefix
import com.tejando.keyboard.keyboard.KeyboardView
import com.tejando.keyboard.keyboard.Layer
import com.tejando.keyboard.vault.VaultActivity

/**
 * O teclado em si. Cada toque numa tecla faz DUAS coisas independentes:
 *  1. [onKeyDown]  -> dispara o som musical no instante do toque (não interfere na digitação)
 *  2. [onText] etc -> insere o texto no app em foco quando o dedo solta
 * Se o áudio falhar ou estiver mudo, a digitação continua igual.
 */
class TejandoKeyboardService : InputMethodService(), KeyboardView.Listener {

    private var keyboardView: KeyboardView? = null
    private lateinit var prefs: KeyboardPrefs
    private lateinit var mixerStore: MixerStore
    private lateinit var clipStore: ClipboardStore
    private val engine = SoundEngine()
    private val sounds = KeySounds(engine)
    private var mixer = MixerState()
    private val main = Handler(Looper.getMainLooper())
    private var clipListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    private val suggestionEngine: LocalSuggestionEngine by lazy { LocalSuggestionEngine(applicationContext) }

    // Resultado de IA/correção aguardando o usuário aceitar
    private var pendingResult: String? = null
    private var pendingTarget: String? = null
    private var pendingTargetWasSelection = false
    private var aiToken = 0

    override fun onCreate() {
        super.onCreate()
        prefs = KeyboardPrefs(this)
        mixerStore = MixerStore(this)
        clipStore = ClipboardStore(this)
        mixer = mixerStore.load()
        engine.update(mixer)
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipListener = ClipboardManager.OnPrimaryClipChangedListener { onClipChanged(cm) }
        cm.addPrimaryClipChangedListener(clipListener)
    }

    override fun onCreateInputView(): View {
        val view = KeyboardView(this)
        view.listener = this
        keyboardView = view
        applyStyle()
        view.mixer = mixer
        view.setRecentEmojis(recentEmojis())
        return view
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val view = keyboardView ?: return
        mixer = mixerStore.load()          // pega mudanças feitas no app de configurações
        engine.update(mixer)
        view.mixer = mixer
        applyStyle()
        view.setEnterLabel(enterLabel(info))
        view.setLayer(initialLayer(info))
        view.resetShift()
        suggestionEngine.personalize = !prefs.privateMode
        refreshState()
        deliverPendingSecret()
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        engine.panic()
        engine.stop()                      // libera o AudioTrack quando o teclado some
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int,
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        refreshState()
    }

    override fun onDestroy() {
        clipListener?.let { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(it) }
        engine.stop()
        keyboardView?.listener = null
        keyboardView = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- som

    override fun onKeyDown(text: String) {
        val info = currentInputEditorInfo
        if (prefs.muteInPasswords && info != null && isPasswordField(info)) return
        try { sounds.onKey(text, mixer) } catch (_: Throwable) { /* áudio nunca pode quebrar a digitação */ }
    }

    override fun onCursorMove(delta: Int) {
        if (currentInputConnection == null) return
        sendDownUpKeyEvents(if (delta < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT)
    }

    override fun onMixerChanged(state: MixerState) {
        mixer = state
        mixerStore.save(state)
        engine.update(state)
    }

    private fun playTestPhrase() {
        if (!mixer.enabled) { toast("Som está mudo."); return }
        val seq = intArrayOf(0, 2, 4, 7, 4, 9, 7, 11)
        seq.forEachIndexed { i, deg ->
            main.postDelayed({
                engine.playNote(if (mixer.instrument == Instrument.OFF || mixer.instrument == Instrument.DRUMS) Instrument.PIANO else mixer.instrument,
                    mixer.scale.midi(mixer.baseMidi, deg))
                if (mixer.drumLayer) engine.playDrum(if (i % 2 == 0) Drum.KICK else Drum.HIHAT, 0.8f)
            }, i * 170L)
        }
    }

    // ---------------------------------------------------------------- KeyboardView.Listener

    override fun onText(text: String) {
        val ic = currentInputConnection ?: return
        learnFromTyping(ic, text)
        if (text == " " && shouldAutoPeriod(ic)) {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
            ic.endBatchEdit()
        } else {
            ic.commitText(text, 1)
        }
        if (isEmoji(text)) { saveRecentEmoji(text); keyboardView?.setRecentEmojis(recentEmojis()) }
        refreshState()
    }

    override fun onDelete() {
        if (currentInputConnection == null) return
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        refreshState()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        val options = info?.imeOptions ?: 0
        val action = options and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (options and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (info == null || noEnterAction ||
            action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            ic.performEditorAction(action)
        }
        refreshState()
    }

    override fun onInputMethodPicker() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    override fun onSuggestionPicked(word: String) {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(40, 0)?.toString().orEmpty()
        ic.beginBatchEdit()
        if (word.length == 1 && !word[0].isLetterOrDigit()) {
            if (before.endsWith(" ")) ic.deleteSurroundingText(1, 0)
            ic.commitText("$word ", 1)
        } else {
            val prefix = currentWordPrefix(before)
            if (prefix.isNotEmpty()) ic.deleteSurroundingText(prefix.length, 0)
            ic.commitText("$word ", 1)
        }
        ic.endBatchEdit()
        refreshState()
    }

    // ---------------------------------------------------------------- ações da barra de ferramentas

    override fun onAction(id: String) {
        when {
            id == "mix:reset" -> {
                mixer = mixerStore.reset(); engine.update(mixer); keyboardView?.mixer = mixer
            }
            id == "mix:test" -> playTestPhrase()
            id == "tool:clip" -> { keyboardView?.setClipboard(clipStore.all()); keyboardView?.setLayer(Layer.CLIPBOARD) }
            id == "tool:vault" -> openVault()
            id == "tool:lang" -> cycleLanguage()
            id == "tool:fix" -> runLocalFix()
            id.startsWith("edit:") -> editAction(id.removePrefix("edit:"))
            id.startsWith("tool:") -> runAi(id.removePrefix("tool:"))
            id.startsWith("clip:") -> handleClip(id)
            id == "res:insert" -> applyResult()
            id == "res:copy" -> copyResult()
            id == "res:discard" -> { pendingResult = null; pendingTarget = null; keyboardView?.setLayer(Layer.LETTERS) }
        }
    }

    /** Desfazer/refazer/selecionar/copiar/cortar/colar. Usa o menu de contexto do campo; se ele não suportar, tenta Ctrl+Z. */
    private fun editAction(a: String) {
        val ic = currentInputConnection ?: return
        val handled = when (a) {
            "undo" -> ic.performContextMenuAction(android.R.id.undo)
            "redo" -> ic.performContextMenuAction(android.R.id.redo)
            "all" -> ic.performContextMenuAction(android.R.id.selectAll)
            "copy" -> ic.performContextMenuAction(android.R.id.copy)
            "cut" -> ic.performContextMenuAction(android.R.id.cut)
            "paste" -> ic.performContextMenuAction(android.R.id.paste)
            else -> true
        }
        if (!handled && (a == "undo" || a == "redo")) {
            val now = SystemClock.uptimeMillis()
            val meta = KeyEvent.META_CTRL_ON or (if (a == "redo") KeyEvent.META_SHIFT_ON else 0)
            ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_Z, 0, meta))
            ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_Z, 0, meta))
        }
        refreshState()
    }

    private fun cycleLanguage() {
        val i = TRANSLATE_LANGS.indexOfFirst { it.first == prefs.translateTarget }
        val next = TRANSLATE_LANGS[(i + 1) % TRANSLATE_LANGS.size]
        prefs.translateTarget = next.first
        keyboardView?.translateLabel = next.first.uppercase()
        toast("Traduzir para: ${next.second}")
    }

    /** Texto alvo: a SELEÇÃO, ou, sem seleção, só a última linha antes do cursor (máx. 300 caracteres). Nunca o campo inteiro. */
    private fun captureTarget(): Boolean {
        val ic = currentInputConnection ?: return false
        val info = currentInputEditorInfo
        if (info != null && isPasswordField(info)) { toast("Desativado em campos de senha."); return false }
        val sel = ic.getSelectedText(0)?.toString()
        if (!sel.isNullOrEmpty()) { pendingTarget = sel; pendingTargetWasSelection = true; return true }
        val line = ic.getTextBeforeCursor(300, 0)?.toString().orEmpty().substringAfterLast('\n')
        if (line.isBlank()) { toast("Escreva ou selecione um texto primeiro."); return false }
        pendingTarget = line; pendingTargetWasSelection = false
        return true
    }

    private fun runLocalFix() {
        if (!captureTarget()) return
        val t = pendingTarget ?: return
        pendingResult = LocalFixer.fix(t)
        keyboardView?.showResult("CORREÇÃO LOCAL (sem internet): só espaços e maiúsculas", pendingResult.orEmpty())
    }

    private fun runAi(name: String) {
        if (prefs.privateMode) { toast("Modo privado ligado: IA desativada."); return }
        val action = when (name) {
            "translate" -> AiAction.TRANSLATE
            "aifix" -> AiAction.FIX
            "rewrite" -> AiAction.REWRITE
            "summarize" -> AiAction.SUMMARIZE
            "organize" -> AiAction.ORGANIZE
            "explain" -> AiAction.EXPLAIN
            "continue" -> AiAction.CONTINUE
            else -> return
        }
        if (!captureTarget()) return
        val target = pendingTarget ?: return
        val langName = TRANSLATE_LANGS.firstOrNull { it.first == prefs.translateTarget }?.second ?: "English"
        val extra = if (action == AiAction.TRANSLATE) langName else null
        val token = ++aiToken
        pendingResult = null
        keyboardView?.showResult("ENVIANDO ${action.label.uppercase()} AO PROVEDOR DE IA…", "Texto enviado (somente este trecho):\n" + target.take(300))
        AiRunner.run(this, action, target, extra) { r ->
            if (token != aiToken) return@run
            when (r) {
                is AiResult.Ok -> {
                    pendingResult = r.text
                    keyboardView?.showResult("RESULTADO — ${action.label}", r.text)
                }
                is AiResult.Fail -> {
                    pendingResult = null
                    keyboardView?.showResult("FALHA", r.message)
                }
            }
        }
    }

    private fun applyResult() {
        val res = pendingResult ?: run { keyboardView?.setLayer(Layer.LETTERS); return }
        val ic = currentInputConnection ?: return
        val tgt = pendingTarget
        ic.beginBatchEdit()
        if (pendingTargetWasSelection) {
            ic.commitText(res, 1)           // substitui a seleção
        } else {
            val before = ic.getTextBeforeCursor(300, 0)?.toString().orEmpty()
            if (tgt != null && before.endsWith(tgt)) ic.deleteSurroundingText(tgt.length, 0)
            ic.commitText(res, 1)
        }
        ic.endBatchEdit()
        pendingResult = null; pendingTarget = null
        keyboardView?.setLayer(Layer.LETTERS)
        refreshState()
    }

    private fun copyResult() {
        val res = pendingResult ?: return
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Tejando", res))
        toast("Copiado.")
    }

    // ---------------------------------------------------------------- área de transferência

    private fun onClipChanged(cm: ClipboardManager) {
        if (prefs.privateMode) return
        val info = currentInputEditorInfo
        if (info != null && isPasswordField(info)) return
        try {
            val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString() ?: return
            clipStore.add(t)
            if (keyboardView?.currentLayer() == Layer.CLIPBOARD) keyboardView?.setClipboard(clipStore.all())
        } catch (_: Exception) { /* o Android pode negar a leitura quando não estamos em foco */ }
    }

    private fun handleClip(id: String) {
        val list = clipStore.all()
        val parts = id.split(":")
        when (parts[1]) {
            "ins" -> list.getOrNull(parts[2].toInt())?.let { currentInputConnection?.commitText(it.text, 1) }
            "pin" -> list.getOrNull(parts[2].toInt())?.let { clipStore.togglePin(it.text) }
            "clear" -> clipStore.clearUnpinned()
            "clearall" -> clipStore.clearAll()
        }
        keyboardView?.setClipboard(clipStore.all())
    }

    // ---------------------------------------------------------------- cofre

    private fun openVault() {
        val info = currentInputEditorInfo
        if (info != null && prefs.privateMode) { /* cofre continua permitido: é ação explícita do usuário */ }
        val i = Intent(this, VaultActivity::class.java).setAction(VaultActivity.ACTION_PICK)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun deliverPendingSecret() {
        val s = takePendingSecret() ?: return
        currentInputConnection?.commitText(s, 1)
    }

    // ---------------------------------------------------------------- emojis recentes

    private fun recentEmojis(): List<String> =
        getSharedPreferences("tejando_prefs", MODE_PRIVATE).getString("recent_emojis", "").orEmpty()
            .split(' ').filter { it.isNotEmpty() }

    private fun saveRecentEmoji(e: String) {
        if (prefs.privateMode) return
        val list = (listOf(e) + recentEmojis().filter { it != e }).take(24)
        getSharedPreferences("tejando_prefs", MODE_PRIVATE).edit().putString("recent_emojis", list.joinToString(" ")).apply()
    }

    private fun isEmoji(t: String): Boolean {
        if (t.isEmpty()) return false
        val cp = t.codePointAt(0)
        return cp >= 0x1F000 || cp in 0x2190..0x2BFF || cp in 0x2600..0x27BF
    }

    // ---------------------------------------------------------------- estado

    private fun learnFromTyping(ic: InputConnection, typed: String) {
        if (prefs.privateMode || !prefs.learnWords) return
        val info = currentInputEditorInfo ?: return
        if (!isPlainTextField(info)) return
        if (typed.length == 1 && !typed[0].isLetter()) {
            val before = ic.getTextBeforeCursor(30, 0)?.toString().orEmpty()
            val w = currentWordPrefix(before)
            if (w.isNotEmpty()) suggestionEngine.userWords.learn(w)
        }
    }

    private fun applyStyle() {
        val view = keyboardView ?: return
        view.style = prefs.style()
        view.translateLabel = prefs.translateTarget.uppercase()
        view.setWallpaper(WallpaperStore.load(this))
    }

    private fun refreshState() {
        updateShiftFromEditor()
        updateSuggestions()
    }

    private fun updateShiftFromEditor() {
        val view = keyboardView ?: return
        val info = currentInputEditorInfo ?: return
        val ic = currentInputConnection ?: return
        val capitalize = info.inputType != InputType.TYPE_NULL && ic.getCursorCapsMode(info.inputType) != 0
        view.autoShift(capitalize)
    }

    private fun updateSuggestions() {
        val view = keyboardView ?: return
        val info = currentInputEditorInfo
        val ic = currentInputConnection
        if (!prefs.suggestions || info == null || ic == null || !isPlainTextField(info)) {
            view.setSuggestions(emptyList())
            return
        }
        val before = ic.getTextBeforeCursor(40, 0)?.toString().orEmpty()
        view.setSuggestions(suggestionEngine.suggest(before))
    }

    private fun shouldAutoPeriod(ic: InputConnection): Boolean {
        val info = currentInputEditorInfo ?: return false
        if (!isPlainTextField(info)) return false
        val before = ic.getTextBeforeCursor(2, 0)?.toString().orEmpty()
        return before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()
    }

    private fun isPasswordField(info: EditorInfo): Boolean {
        val type = info.inputType
        return when (type and InputType.TYPE_MASK_CLASS) {
            InputType.TYPE_CLASS_TEXT -> when (type and InputType.TYPE_MASK_VARIATION) {
                InputType.TYPE_TEXT_VARIATION_PASSWORD,
                InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
                InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD -> true
                else -> false
            }
            InputType.TYPE_CLASS_NUMBER -> (type and InputType.TYPE_MASK_VARIATION) == InputType.TYPE_NUMBER_VARIATION_PASSWORD
            else -> false
        }
    }

    private fun isPlainTextField(info: EditorInfo): Boolean {
        val type = info.inputType
        if ((type and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return false
        if ((type and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) return false
        return when (type and InputType.TYPE_MASK_VARIATION) {
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_URI -> false
            else -> true
        }
    }

    private fun initialLayer(info: EditorInfo): Layer =
        when (info.inputType and InputType.TYPE_MASK_CLASS) {
            InputType.TYPE_CLASS_NUMBER,
            InputType.TYPE_CLASS_PHONE,
            InputType.TYPE_CLASS_DATETIME -> Layer.SYMBOLS
            else -> Layer.LETTERS
        }

    private fun enterLabel(info: EditorInfo): String? {
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return null
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> getString(R.string.enter_go)
            EditorInfo.IME_ACTION_SEARCH -> getString(R.string.enter_search)
            EditorInfo.IME_ACTION_SEND -> getString(R.string.enter_send)
            EditorInfo.IME_ACTION_NEXT -> getString(R.string.enter_next)
            EditorInfo.IME_ACTION_DONE -> getString(R.string.enter_done)
            else -> null
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    companion object {
        @Volatile private var pendingSecret: String? = null
        @Volatile private var pendingAt = 0L

        /** Chamado pela tela do cofre depois da digital. O segredo fica só em memória, por no máximo 60 s. */
        fun setPendingSecret(s: String) { pendingSecret = s; pendingAt = SystemClock.uptimeMillis() }

        private fun takePendingSecret(): String? {
            val s = pendingSecret ?: return null
            val fresh = SystemClock.uptimeMillis() - pendingAt < 60_000
            pendingSecret = null
            return if (fresh) s else null
        }
    }
}
