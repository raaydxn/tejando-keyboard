package com.tejando.keyboard.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

/**
 * Guarda o papel de parede escolhido na galeria numa cópia privada do app
 * (filesDir/wallpaper.jpg), já reduzida. Assim o teclado não depende de permissão
 * de galeria nem do URI original continuar válido.
 */
object WallpaperStore {

    private const val FILE_NAME = "wallpaper.jpg"
    private const val TMP_NAME = "wallpaper.tmp"

    private var cached: Bitmap? = null
    private var cachedStamp = -1L

    private fun file(context: Context) = File(context.filesDir, FILE_NAME)

    @Synchronized
    fun load(context: Context): Bitmap? {
        val f = file(context)
        if (!f.exists()) {
            cached = null
            cachedStamp = -1L
            return null
        }
        val stamp = f.lastModified()
        if (cached != null && stamp == cachedStamp) return cached
        val bmp = try {
            BitmapFactory.decodeFile(f.absolutePath)
        } catch (e: OutOfMemoryError) {
            null
        }
        cached = bmp
        cachedStamp = if (bmp != null) stamp else -1L
        return bmp
    }

    @Synchronized
    fun clear(context: Context) {
        file(context).delete()
        cached = null
        cachedStamp = -1L
    }

    /** Copia e reduz a imagem do [uri]. Retorna false se não deu pra ler. */
    @Synchronized
    fun importFrom(context: Context, uri: Uri, maxSide: Int = 1600): Boolean {
        return try {
            doImport(context, uri, maxSide)
        } catch (e: Exception) {
            false
        } catch (e: OutOfMemoryError) {
            false
        }
    }

    private fun doImport(context: Context, uri: Uri, maxSide: Int): Boolean {
        val resolver = context.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2

        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOpts)
        } ?: return false

        val rotation = try {
            resolver.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
        } catch (e: Exception) {
            0
        }

        val longest = max(raw.width, raw.height)
        val scale = if (longest > maxSide) maxSide.toFloat() / longest else 1f
        val bmp = if (rotation != 0 || scale != 1f) {
            val m = Matrix()
            if (rotation != 0) m.postRotate(rotation.toFloat())
            if (scale != 1f) m.postScale(scale, scale)
            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        } else {
            raw
        }

        val tmp = File(context.filesDir, TMP_NAME)
        FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        val dest = file(context)
        if (dest.exists()) dest.delete()
        val ok = tmp.renameTo(dest)
        cached = null
        cachedStamp = -1L
        return ok
    }
}
