package com.tejando.keyboard.engine

/**
 * Ponto de extensão para IA (reescrever texto, responder mensagem, traduzir...).
 *
 * Hoje é só o contrato: o botão ✦ da barra de cima chama [onInvoke]. Para plugar uma IA
 * de verdade você vai precisar de: permissão INTERNET no manifest, chamada assíncrona
 * (coroutines/thread) e um jeito do usuário colocar a própria chave de API.
 * Por padrão o teclado NÃO tem permissão de internet.
 */
interface AiAssistant {
    val isConfigured: Boolean

    /** @return texto para inserir no campo, ou null para não fazer nada. */
    fun onInvoke(textBeforeCursor: String): String?
}

class NoOpAiAssistant : AiAssistant {
    override val isConfigured: Boolean = false
    override fun onInvoke(textBeforeCursor: String): String? = null
}
