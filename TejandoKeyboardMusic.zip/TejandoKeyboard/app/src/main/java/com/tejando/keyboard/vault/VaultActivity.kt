package com.tejando.keyboard.vault

import android.app.AlertDialog
import android.os.Bundle
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.tejando.keyboard.TejandoKeyboardService
import com.tejando.keyboard.security.CryptoBox
import com.tejando.keyboard.ui.Ui
import org.json.JSONObject
import javax.crypto.Cipher

/**
 * Cofre de senhas protegido pela digital.
 *
 * Cada entrada é cifrada com uma chave do Android Keystore que EXIGE autenticação biométrica a cada uso.
 * Sem a digital não há como ler o conteúdo, nem este app nem ninguém. Se o usuário cadastrar uma nova digital
 * no aparelho, o Android invalida a chave e as entradas ficam ilegíveis (comportamento de segurança do sistema).
 *
 * Dois modos:
 *  - gerenciar (aberto pelo app): listar, adicionar, apagar
 *  - escolher (aberto pelo teclado, action = PICK): toca numa entrada, confirma a digital e escolhe inserir
 *    usuário ou senha. O texto é entregue ao teclado, que o digita no campo quando o foco voltar.
 *
 * Observação: um teclado não pode mostrar a janela da digital por cima de outro app; por isso o fluxo abre esta tela.
 * Para preenchimento de login em apps/sites, o Autofill do Android é o caminho mais robusto (não implementado aqui).
 */
class VaultActivity : FragmentActivity() {

    private lateinit var store: VaultStore
    private lateinit var list: LinearLayout
    private val pickMode get() = intent?.action == ACTION_PICK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        store = VaultStore(this)
        val root = Ui.root(this)
        root.addView(Ui.title(this, "Cofre de senhas"))
        root.addView(Ui.note(this, "Protegido pela digital. Cada item só abre com a sua biometria. Não é sincronizado nem enviado a lugar nenhum."))
        if (!biometricOk()) {
            root.addView(Ui.note(this, "Este aparelho não tem biometria forte cadastrada (digital ou rosto classe forte). Cadastre uma nas configurações do Android para usar o cofre."))
        } else {
            if (!pickMode) root.addView(Ui.button(this, "Adicionar item") { addDialog() })
            list = Ui.root(this)
            root.addView(list)
        }
        if (pickMode) root.addView(Ui.button(this, "Fechar", false) { finish() })
        setContentView(Ui.screen(this, root))
        if (biometricOk()) refresh()
    }

    private fun biometricOk() =
        BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

    private fun refresh() {
        list.removeAllViews()
        val items = store.all()
        if (items.isEmpty()) list.addView(Ui.note(this, "Nenhum item guardado."))
        items.forEach { e ->
            list.addView(Ui.button(this, "🔑  " + e.title, true) { openEntry(e) })
            if (!pickMode) list.addView(Ui.button(this, "Apagar \"${e.title}\"", false) {
                AlertDialog.Builder(this).setMessage("Apagar \"${e.title}\" do cofre?")
                    .setPositiveButton("Apagar") { _, _ -> store.remove(e.id); refresh() }
                    .setNegativeButton("Cancelar", null).show()
            })
        }
    }

    private fun prompt(title: String, cipher: Cipher, onOk: (Cipher) -> Unit) {
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setNegativeButtonText("Cancelar")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        val p = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                val c = result.cryptoObject?.cipher ?: return
                try { onOk(c) } catch (e: Exception) { toast("Não foi possível concluir (${e.javaClass.simpleName}).") }
            }
            override fun onAuthenticationError(code: Int, msg: CharSequence) {
                if (code != BiometricPrompt.ERROR_USER_CANCELED && code != BiometricPrompt.ERROR_NEGATIVE_BUTTON) toast(msg.toString())
            }
        })
        p.authenticate(info, BiometricPrompt.CryptoObject(cipher))
    }

    private fun addDialog() {
        val box = Ui.root(this)
        val t = Ui.edit(this, "Nome (ex.: Gmail)")
        val u = Ui.edit(this, "Usuário ou e-mail")
        val p = Ui.edit(this, "Senha", password = true)
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0)
        box.addView(t); box.addView(u); box.addView(p)
        AlertDialog.Builder(this).setTitle("Novo item").setView(box)
            .setPositiveButton("Salvar com digital") { _, _ ->
                val title = t.text.toString().trim()
                val json = JSONObject().put("u", u.text.toString()).put("p", p.text.toString()).toString()
                if (title.isEmpty()) { toast("Dê um nome ao item."); return@setPositiveButton }
                try {
                    prompt("Confirme para guardar \"$title\"", CryptoBox.vaultEncryptCipher()) { c ->
                        store.add(title, CryptoBox.finishEncrypt(c, json)); refresh()
                    }
                } catch (e: Exception) { toast("Não foi possível preparar a chave segura (${e.javaClass.simpleName}).") }
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun openEntry(e: VaultEntry) {
        try {
            prompt("Confirme para abrir \"${e.title}\"", CryptoBox.vaultDecryptCipher(e.payload)) { c ->
                val o = JSONObject(CryptoBox.finishDecrypt(c, e.payload))
                val user = o.optString("u"); val pass = o.optString("p")
                if (pickMode) {
                    val opts = arrayOf("Inserir usuário/e-mail", "Inserir senha")
                    AlertDialog.Builder(this).setTitle(e.title).setItems(opts) { _, which ->
                        TejandoKeyboardService.setPendingSecret(if (which == 0) user else pass)
                        finish()
                    }.show()
                } else {
                    AlertDialog.Builder(this).setTitle(e.title)
                        .setMessage("Usuário: $user\nSenha: " + "•".repeat(pass.length.coerceIn(4, 16)))
                        .setPositiveButton("Fechar", null).show()
                }
            }
        } catch (ex: android.security.keystore.KeyPermanentlyInvalidatedException) {
            toast("A biometria do aparelho mudou e o Android invalidou a chave. Apague este item e crie de novo.")
        } catch (ex: Exception) {
            toast("Não foi possível abrir (${ex.javaClass.simpleName}).")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    companion object { const val ACTION_PICK = "com.tejando.keyboard.VAULT_PICK" }
}
