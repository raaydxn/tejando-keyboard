package com.tejando.keyboard.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Process
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Motor de áudio próprio (síntese em tempo real, sem samples, 100% offline).
 *
 * - Uma thread de render escreve blocos pequenos em um AudioTrack PERFORMANCE_MODE_LOW_LATENCY.
 * - Quem toca (teclado) só enfileira eventos; a thread de render é a única dona das vozes.
 * - Cadeia de efeitos portada do grok-workspace: drive -> filtro (tone) -> delay com feedback,
 *   mais um reverb simples (Schroeder) -> compressor/limitador suave -> master.
 * - Limite de 24 vozes; a mais antiga é cortada.
 *
 * Latência real depende do aparelho: no Android o AudioTrack de baixa latência costuma ficar
 * entre ~20 e ~80 ms. Isto NÃO é medido automaticamente; veja Testes e diagnóstico.
 */
class SoundEngine(val sampleRate: Int = 44100) {

    private sealed class Ev {
        class Note(val inst: Instrument, val midi: Int, val vel: Float, val dur: Float) : Ev()
        class DrumHit(val drum: Drum, val vel: Float, val tail: Float) : Ev()
        object Panic : Ev()
    }

    @Volatile var state: MixerState = MixerState()
    @Volatile var peakLevel = 0f; private set
    @Volatile var framesRendered = 0L; private set
    @Volatile var lastError: String? = null; private set

    private val queue = ConcurrentLinkedQueue<Ev>()
    private val voices = ArrayList<Voice>()
    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null

    // efeitos
    private val toneL = Biquad(sampleRate)
    private var lastTone = -1
    private val delayBuf = FloatArray(sampleRate * 2)
    private var delayPos = 0
    private val reverb = Reverb(sampleRate)
    private var delayLP = 0f
    private var env = 0f

    // ------------------------------------------------------------------ API

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "tejando-audio").also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        thread?.let { try { it.join(400) } catch (_: InterruptedException) {} }
        thread = null
    }

    fun update(s: MixerState) { state = s }

    fun playNote(inst: Instrument, midi: Int, velocity: Float = 1f) {
        val s = state
        if (!s.enabled || inst == Instrument.OFF || inst == Instrument.DRUMS) return
        if (!running) start()
        queue.add(Ev.Note(inst, midi, velocity, s.noteSeconds))
    }

    fun playDrum(d: Drum, velocity: Float = 1f) {
        val s = state
        if (!s.enabled) return
        if (!running) start()
        queue.add(Ev.DrumHit(d, velocity * s.drumVolume / 100f, 0.7f + s.noteLen / 100f * 0.95f))
    }

    fun panic() { queue.add(Ev.Panic) }

    // ------------------------------------------------------------------ loop

    private fun loop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val frames = 256
        var tr: AudioTrack? = null
        try {
            val minBuf = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val bufBytes = max(minBuf, frames * 2 * 2)
            tr = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build(),
                )
                .setAudioFormat(
                    AudioFormat.Builder().setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
                )
                .setBufferSizeInBytes(bufBytes)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
            track = tr
            tr.play()
            lastError = null
        } catch (t: Throwable) {
            lastError = "AudioTrack: ${t.message}"
            running = false
            return
        }

        val mix = FloatArray(frames)
        val pcm = ShortArray(frames)
        var idle = 0
        while (running) {
            drainQueue()
            java.util.Arrays.fill(mix, 0f)
            val it = voices.iterator()
            while (it.hasNext()) {
                val v = it.next()
                v.render(mix, frames)
                v.age += frames
                if (v.done) it.remove()
            }
            val silent = voices.isEmpty()
            process(mix, frames)
            var pk = 0f
            for (i in 0 until frames) {
                val x = mix[i].coerceIn(-1f, 1f)
                pk = max(pk, abs(x))
                pcm[i] = (x * 32767f).toInt().toShort()
            }
            peakLevel = pk
            framesRendered += frames
            val w = tr.write(pcm, 0, frames)
            if (w < 0) { lastError = "write=$w"; break }
            // sem vozes e sem cauda audível por ~3s: dorme para não gastar bateria
            if (silent && pk < 0.0005f) idle++ else idle = 0
            if (idle > sampleRate * 3 / frames) {
                tr.pause(); tr.flush()
                while (running && queue.isEmpty()) try { Thread.sleep(15) } catch (_: InterruptedException) { break }
                if (running) { tr.play(); idle = 0 }
            }
        }
        try { tr.stop() } catch (_: Throwable) {}
        tr.release()
        track = null
    }

    private fun drainQueue() {
        while (true) {
            val ev = queue.poll() ?: break
            val sr = sampleRate
            when (ev) {
                is Ev.Panic -> voices.clear()
                is Ev.Note -> {
                    val f = Notes.freq(ev.midi.toDouble()).toFloat()
                    val v: Voice = when (ev.inst) {
                        Instrument.GUITAR -> StringVoice(sr, f, ev.vel, ev.dur, 0.85f)
                        Instrument.PLUCK -> StringVoice(sr, f, ev.vel, ev.dur * 0.6f, 0.45f)
                        Instrument.PIANO -> PianoVoice(sr, f, ev.vel, ev.dur)
                        Instrument.BASS -> BassVoice(sr, f, ev.vel, ev.dur)
                        else -> OscVoice(sr, f, ev.inst, ev.vel, ev.dur)
                    }
                    add(v)
                }
                is Ev.DrumHit -> for (v in DrumFactory.make(sr, ev.drum, ev.tail)) {
                    add(scaled(v, ev.vel))
                }
            }
        }
    }

    private fun scaled(v: Voice, g: Float): Voice = if (g >= 0.999f) v else object : Voice() {
        val tmp = FloatArray(512)
        override fun render(out: FloatArray, n: Int) {
            java.util.Arrays.fill(tmp, 0, n, 0f)
            v.render(tmp, n)
            for (i in 0 until n) out[i] += tmp[i] * g
            done = v.done
        }
    }

    private fun add(v: Voice) {
        while (voices.size >= MAX_VOICES) voices.removeAt(0)
        voices.add(v)
    }

    private fun process(buf: FloatArray, n: Int) {
        val s = state
        val drive = s.drive / 100f
        val toneHz = (280.0 * Math.pow(14000.0 / 280.0, (s.tone / 100.0))).toInt()
        if (toneHz != lastTone) { toneL.set('l', toneHz.toFloat(), 0.7f); lastTone = toneHz }
        val echo = s.echo / 100f
        val delaySamples = (sampleRate * min(1.2f, max(0.08f, 30f / max(40, s.bpm)))).toInt().coerceIn(1, delayBuf.size - 1)
        val master = s.volume / 100f * 0.85f
        val preGain = 0.5f + drive * 2.5f
        val postGain = 0.72f / (1f + drive * 1.45f)
        val rv = s.reverb / 100f
        for (i in 0 until n) {
            var x = buf[i] * preGain
            x = if (drive > 0.01f) tanh(x * (1f + drive * 4f)) / (1f + drive * 1.2f) else x
            x *= postGain
            x = toneL.process(x)
            // delay
            val rp = (delayPos - delaySamples + delayBuf.size) % delayBuf.size
            val d = delayBuf[rp]
            delayLP += (d - delayLP) * 0.35f
            delayBuf[delayPos] = x + delayLP * min(0.72f, echo * 0.68f)
            delayPos = (delayPos + 1) % delayBuf.size
            var y = x * (1f - echo * 0.22f) + d * echo * 0.5f
            y += reverb.process(y) * rv * 0.6f
            // compressor/limitador simples
            val a = abs(y)
            env = if (a > env) env + (a - env) * 0.3f else env + (a - env) * 0.0008f
            val g = if (env > 0.7f) 0.7f / env else 1f
            buf[i] = tanh(y * g * master * 1.6f)
        }
    }

    // ------------------------------------------------------------------ render offline (testes)

    /**
     * Renderiza uma nota usando o MESMO código de vozes e efeitos, sem abrir o AudioTrack.
     * Serve para os testes confirmarem que o sinal gerado não é silêncio e tem a frequência certa.
     */
    fun renderOffline(inst: Instrument, midi: Int, seconds: Float = 0.6f, st: MixerState = state): FloatArray {
        val tmp = SoundEngine(sampleRate)
        tmp.state = st.copy(enabled = true)
        val f = Notes.freq(midi.toDouble()).toFloat()
        val voice: Voice = when (inst) {
            Instrument.GUITAR -> StringVoice(sampleRate, f, 1f, st.noteSeconds, 0.85f)
            Instrument.PLUCK -> StringVoice(sampleRate, f, 1f, st.noteSeconds * 0.6f, 0.45f)
            Instrument.PIANO -> PianoVoice(sampleRate, f, 1f, st.noteSeconds)
            Instrument.BASS -> BassVoice(sampleRate, f, 1f, st.noteSeconds)
            else -> OscVoice(sampleRate, f, inst, 1f, st.noteSeconds)
        }
        tmp.voices.add(voice)
        val total = (seconds * sampleRate).toInt()
        val out = FloatArray(total)
        val block = FloatArray(256)
        var pos = 0
        while (pos < total) {
            val n = min(256, total - pos)
            java.util.Arrays.fill(block, 0f)
            for (v in tmp.voices) v.render(block, n)
            tmp.process(block, n)
            System.arraycopy(block, 0, out, pos, n)
            pos += n
        }
        return out
    }

    fun renderDrumOffline(d: Drum, seconds: Float = 0.5f): FloatArray {
        val tmp = SoundEngine(sampleRate)
        tmp.state = state.copy(enabled = true)
        for (v in DrumFactory.make(sampleRate, d, 1.0f)) tmp.voices.add(v)
        val total = (seconds * sampleRate).toInt()
        val out = FloatArray(total)
        val block = FloatArray(256)
        var pos = 0
        while (pos < total) {
            val n = min(256, total - pos)
            java.util.Arrays.fill(block, 0f)
            for (v in tmp.voices) v.render(block, n)
            tmp.process(block, n)
            System.arraycopy(block, 0, out, pos, n)
            pos += n
        }
        return out
    }

    companion object {
        const val MAX_VOICES = 24

        fun rms(x: FloatArray): Float {
            if (x.isEmpty()) return 0f
            var s = 0.0
            for (v in x) s += v * v
            return sqrt(s / x.size).toFloat()
        }

        /** Frequência estimada por contagem de cruzamentos de zero (aproximada). */
        fun estimateHz(x: FloatArray, sr: Int, from: Int = 0, to: Int = x.size): Float {
            var crossings = 0
            for (i in from + 1 until to) if ((x[i - 1] < 0f) != (x[i] < 0f)) crossings++
            val sec = (to - from).toFloat() / sr
            return if (sec > 0f) crossings / 2f / sec else 0f
        }
    }
}

/** Reverb de Schroeder: 4 combs em paralelo + 2 allpass em série. */
private class Reverb(sr: Int) {
    private class Comb(val buf: FloatArray, val fb: Float) {
        var pos = 0; var lp = 0f
        fun process(x: Float): Float {
            val o = buf[pos]
            lp += (o - lp) * 0.3f
            buf[pos] = x + lp * fb
            pos = (pos + 1) % buf.size
            return o
        }
    }
    private class AllPass(val buf: FloatArray) {
        var pos = 0
        fun process(x: Float): Float {
            val b = buf[pos]
            val o = -x + b
            buf[pos] = x + b * 0.5f
            pos = (pos + 1) % buf.size
            return o
        }
    }
    private val combs = arrayOf(1557, 1617, 1491, 1422).map { Comb(FloatArray((it * sr / 44100)), 0.82f) }
    private val aps = arrayOf(556, 441).map { AllPass(FloatArray((it * sr / 44100))) }
    fun process(x: Float): Float {
        var s = 0f
        for (c in combs) s += c.process(x)
        s *= 0.25f
        for (a in aps) s = a.process(s)
        return s
    }
}
