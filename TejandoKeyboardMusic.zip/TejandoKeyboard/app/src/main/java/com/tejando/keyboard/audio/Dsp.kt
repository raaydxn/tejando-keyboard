package com.tejando.keyboard.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Filtro biquad (fórmulas RBJ). Usado em lowpass/highpass/bandpass. */
class Biquad(private val sr: Int) {
    private var b0 = 1f; private var b1 = 0f; private var b2 = 0f; private var a1 = 0f; private var a2 = 0f
    private var x1 = 0f; private var x2 = 0f; private var y1 = 0f; private var y2 = 0f

    fun set(type: Char, freq: Float, q: Float) {
        val f = freq.coerceIn(20f, sr * 0.45f)
        val w = 2.0 * PI * f / sr
        val alpha = sin(w) / (2.0 * q.coerceAtLeast(0.1f))
        val c = cos(w)
        val a0 = 1.0 + alpha
        val nb0: Double; val nb1: Double; val nb2: Double
        when (type) {
            'h' -> { nb0 = (1 + c) / 2; nb1 = -(1 + c); nb2 = (1 + c) / 2 }
            'b' -> { nb0 = alpha; nb1 = 0.0; nb2 = -alpha }
            else -> { nb0 = (1 - c) / 2; nb1 = 1 - c; nb2 = (1 - c) / 2 }
        }
        b0 = (nb0 / a0).toFloat(); b1 = (nb1 / a0).toFloat(); b2 = (nb2 / a0).toFloat()
        a1 = ((-2.0 * c) / a0).toFloat(); a2 = ((1.0 - alpha) / a0).toFloat()
    }

    fun process(x: Float): Float {
        val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1; x1 = x; y2 = y1; y1 = y
        return y
    }
}

/** Voz: soma amostras mono em [out]. */
abstract class Voice {
    var done = false
    var age = 0L
    abstract fun render(out: FloatArray, n: Int)
}

private fun expDecay(t: Float, tau: Float) = exp(-t / tau)

/** Osciladores detunados (timbres de synth) com envelope attack/decay/release. */
class OscVoice(
    private val sr: Int, freq: Float, private val kind: Instrument, private val vel: Float, private val dur: Float,
) : Voice() {
    private val detunes = when (kind) {
        Instrument.SYNTH_SAW, Instrument.SYNTH_SQUARE -> floatArrayOf(0.9954f, 1.0046f)
        else -> floatArrayOf(1f)
    }
    private val inc = FloatArray(detunes.size) { freq * detunes[it] / sr }
    private val ph = FloatArray(detunes.size)
    private var t = 0f
    private val attack = if (kind == Instrument.SYNTH_SINE) 0.02f else 0.008f
    private val release = 0.06f + dur * 0.15f

    private fun wave(p: Float): Float = when (kind) {
        Instrument.SYNTH_SAW -> 2f * p - 1f
        Instrument.SYNTH_SQUARE -> if (p < 0.5f) 0.7f else -0.7f
        Instrument.SYNTH_TRI -> 4f * abs(p - 0.5f) - 1f
        else -> sin(2.0 * PI * p).toFloat()
    }

    override fun render(out: FloatArray, n: Int) {
        val dt = 1f / sr
        val gateEnd = dur
        for (i in 0 until n) {
            var env = if (t < attack) t / attack else 1f
            env *= if (t < gateEnd) 0.55f + 0.45f * expDecay(t, 0.25f + dur * 0.3f) else 0f
            if (t >= gateEnd) {
                val r = (t - gateEnd) / release
                if (r >= 1f) { done = true; return }
                env = (0.55f + 0.45f * expDecay(gateEnd, 0.25f + dur * 0.3f)) * (1f - r)
            }
            var s = 0f
            for (k in ph.indices) {
                s += wave(ph[k])
                ph[k] += inc[k]; if (ph[k] >= 1f) ph[k] -= 1f
            }
            out[i] += s / ph.size * env * vel * 0.30f
            t += dt
        }
    }
}

/** Karplus-Strong: corda dedilhada (guitarra e pluck). */
class StringVoice(
    private val sr: Int, freq: Float, private val vel: Float, dur: Float, bright: Float,
) : Voice() {
    private val len = max(2, (sr / freq).toInt())
    private val buf = FloatArray(len)
    private var pos = 0
    private val damp = (0.992f + 0.006f * dur.coerceIn(0f, 2f) / 2f).coerceAtMost(0.9985f)
    private val blend = bright
    private var last = 0f
    private var samples = 0
    private val maxSamples = (sr * (0.4f + dur * 1.6f)).toInt()

    init {
        var seed = (freq * 7919f).toInt() or 1
        for (i in 0 until len) {
            seed = seed * 1103515245 + 12345
            val r = ((seed shr 8) and 0xFFFF) / 32768f - 1f
            buf[i] = r * (0.6f + 0.4f * blend)
        }
    }

    override fun render(out: FloatArray, n: Int) {
        for (i in 0 until n) {
            val cur = buf[pos]
            val nxt = buf[(pos + 1) % len]
            val v = (cur + nxt) * 0.5f * damp
            buf[pos] = v
            pos = (pos + 1) % len
            var fade = 1f
            val remain = maxSamples - samples
            if (remain < sr / 10) fade = max(0f, remain / (sr / 10f))
            last += (v - last) * (0.35f + 0.6f * blend)
            out[i] += last * vel * 0.9f * fade
            samples++
            if (samples >= maxSamples) { done = true; return }
        }
    }
}

/** Piano aditivo: parciais levemente inarmônicas, agudos decaem mais rápido. */
class PianoVoice(private val sr: Int, private val freq: Float, private val vel: Float, private val dur: Float) : Voice() {
    private val partials = 7
    private val ph = FloatArray(partials)
    private var t = 0f
    private val total = 0.5f + dur * 1.8f

    override fun render(out: FloatArray, n: Int) {
        val dt = 1f / sr
        for (i in 0 until n) {
            if (t > total) { done = true; return }
            var s = 0f
            for (k in 0 until partials) {
                val h = k + 1
                val f = freq * h * (1f + 0.0004f * h * h)
                if (f > sr * 0.45f) break
                ph[k] += f / sr; if (ph[k] >= 1f) ph[k] -= 1f
                val amp = 1f / (h * 0.9f + 0.1f)
                s += sin(2.0 * PI * ph[k]).toFloat() * amp * expDecay(t, (total / 2.2f) / (1f + 0.55f * k))
            }
            val att = min(1f, t / 0.003f)
            val tail = if (total - t < 0.08f) (total - t) / 0.08f else 1f
            out[i] += s * att * tail * vel * 0.26f
            t += dt
        }
    }
}

/** Baixo: fundamental + harmônico leve, com ataque percussivo. */
class BassVoice(private val sr: Int, private val freq: Float, private val vel: Float, private val dur: Float) : Voice() {
    private var p = 0f
    private var t = 0f
    private val total = 0.25f + dur * 0.9f
    override fun render(out: FloatArray, n: Int) {
        val dt = 1f / sr
        for (i in 0 until n) {
            if (t > total) { done = true; return }
            p += freq / sr; if (p >= 1f) p -= 1f
            val s = sin(2.0 * PI * p).toFloat() + 0.35f * sin(4.0 * PI * p).toFloat() + 0.12f * (2f * p - 1f)
            val env = min(1f, t / 0.006f) * expDecay(t, total / 2.4f) * (if (total - t < 0.05f) (total - t) / 0.05f else 1f)
            out[i] += s * env * vel * 0.38f
            t += dt
        }
    }
}

/** Tom com glissando de frequência (bumbo, tons, clave, conga...). */
class SweepVoice(
    private val sr: Int, private val f0: Float, private val f1: Float, private val dur: Float,
    private val wave: Char, private val peak: Float, delay: Float = 0f,
) : Voice() {
    private var p = 0f
    private var t = -delay
    override fun render(out: FloatArray, n: Int) {
        val dt = 1f / sr
        for (i in 0 until n) {
            if (t >= dur) { done = true; return }
            if (t >= 0f) {
                val f = f0 * (f1 / f0).pow(t / dur)
                p += f / sr; if (p >= 1f) p -= 1f
                val s = when (wave) {
                    's' -> if (p < 0.5f) 1f else -1f
                    't' -> 4f * abs(p - 0.5f) - 1f
                    else -> sin(2.0 * PI * p).toFloat()
                }
                out[i] += s * peak * expDecay(t, dur / 4f) * min(1f, t / 0.002f)
            }
            t += dt
        }
    }
}

/** Rajada de ruído filtrado (caixa, chimbal, prato, palmas, chocalho). */
class NoiseVoice(
    sr: Int, private val dur: Float, type: Char, freq: Float, q: Float, private val peak: Float, delay: Float = 0f,
    private val sr2: Int = sr,
) : Voice() {
    private val filt = Biquad(sr).also { it.set(type, freq, q) }
    private var t = -delay
    private var seed = 22222 + (freq * 13f).toInt()
    override fun render(out: FloatArray, n: Int) {
        val dt = 1f / sr2
        for (i in 0 until n) {
            if (t >= dur) { done = true; return }
            if (t >= 0f) {
                seed = seed * 1664525 + 1013904223
                val r = (seed shr 9) / 4194304f - 1f
                out[i] += filt.process(r) * peak * expDecay(t, dur / 4f) * min(1f, t / 0.003f)
            }
            t += dt
        }
    }
}

/** Dois quadrados filtrados (sino de vaca). */
class CowbellVoice(private val sr: Int, private val dur: Float, private val peak: Float) : Voice() {
    private val filt = Biquad(sr).also { it.set('b', 900f, 2f) }
    private var p1 = 0f; private var p2 = 0f; private var t = 0f
    override fun render(out: FloatArray, n: Int) {
        val dt = 1f / sr
        for (i in 0 until n) {
            if (t >= dur) { done = true; return }
            p1 += 540f / sr; if (p1 >= 1f) p1 -= 1f
            p2 += 800f / sr; if (p2 >= 1f) p2 -= 1f
            val s = (if (p1 < 0.5f) 1f else -1f) + (if (p2 < 0.5f) 1f else -1f)
            out[i] += filt.process(s) * peak * expDecay(t, dur / 4f)
            t += dt
        }
    }
}

/** Receitas de bateria portadas do playDrum() do grok-workspace. */
object DrumFactory {
    fun make(sr: Int, d: Drum, tail: Float): List<Voice> = when (d) {
        Drum.KICK -> listOf(SweepVoice(sr, 172f, 46f, min(0.42f, 0.28f * tail + 0.12f), 'n', 0.95f), SweepVoice(sr, 980f, 980f, 0.018f, 'n', 0.16f))
        Drum.SNARE -> listOf(NoiseVoice(sr, 0.16f * min(tail, 1.4f), 'h', 1800f, 0.7f, 0.55f), SweepVoice(sr, 196f, 150f, 0.12f, 't', 0.4f))
        Drum.HIHAT -> listOf(NoiseVoice(sr, 0.045f, 'h', 7000f, 0.8f, 0.28f))
        Drum.OPENHAT -> listOf(NoiseVoice(sr, min(0.55f, 0.22f * tail), 'b', 8500f, 0.55f, 0.26f))
        Drum.CLAP -> listOf(
            NoiseVoice(sr, 0.04f, 'b', 1500f, 0.8f, 0.4f), NoiseVoice(sr, 0.05f, 'b', 1600f, 0.8f, 0.38f, 0.012f),
            NoiseVoice(sr, 0.14f, 'b', 1400f, 0.7f, 0.32f, 0.028f),
        )
        Drum.RIM -> listOf(SweepVoice(sr, 680f, 420f, 0.045f, 's', 0.16f), NoiseVoice(sr, 0.03f, 'h', 2500f, 0.6f, 0.22f))
        Drum.TOM_HI -> listOf(SweepVoice(sr, 250f, 150f, 0.28f * tail, 'n', 0.7f))
        Drum.TOM_MID -> listOf(SweepVoice(sr, 180f, 110f, 0.32f * tail, 'n', 0.72f))
        Drum.TOM_LO -> listOf(SweepVoice(sr, 120f, 72f, 0.38f * tail, 'n', 0.75f))
        Drum.CRASH -> listOf(NoiseVoice(sr, min(1.6f, 0.85f * tail), 'b', 4800f, 0.4f, 0.32f))
        Drum.RIDE -> listOf(NoiseVoice(sr, min(1.15f, 0.6f * tail), 'h', 5500f, 0.5f, 0.2f), SweepVoice(sr, 3200f, 2800f, 0.18f, 's', 0.04f))
        Drum.COWBELL -> listOf(CowbellVoice(sr, min(0.45f, 0.28f * tail), 0.14f))
        Drum.SHAKER -> listOf(NoiseVoice(sr, 0.07f, 'h', 6500f, 0.7f, 0.22f), NoiseVoice(sr, 0.08f, 'h', 7200f, 0.7f, 0.16f, 0.05f))
        Drum.CLAVE -> listOf(SweepVoice(sr, 2450f, 1900f, 0.07f, 'n', 0.32f))
        Drum.CONGA -> listOf(SweepVoice(sr, 210f, 140f, 0.26f * tail, 'n', 0.62f), NoiseVoice(sr, 0.025f, 'b', 900f, 0.8f, 0.18f))
    }
}
