package com.tejando.keyboard.audio

/**
 * Liga as teclas ao motor de áudio. É chamado no instante em que o dedo toca a tecla
 * (a letra continua sendo inserida normalmente pelo serviço quando o dedo solta).
 *
 * Regras:
 *  - letras -> grau da escala escolhida, na ordem física do QWERTY, no instrumento principal
 *  - números / pontuação / espaço -> seus próprios instrumentos configuráveis
 *  - "Bateria junto": uma camada rítmica extra (espaço = bumbo, vogais = chimbal, pontuação = caixa)
 *  - Backspace / Enter: só fazem clique se "clique mecânico" estiver ligado
 */
class KeySounds(private val engine: SoundEngine) {

    fun onKey(text: String, s: MixerState) {
        if (!s.enabled || text.isEmpty()) return
        if (text == "\b" || text == "\n") {
            if (s.clickFx) engine.playDrum(if (text == "\n") Drum.CLAP else Drum.RIM, 0.6f)
            return
        }
        val ch = text[0]
        val group = KeyMap.groupOf(ch) ?: return
        val inst = when (group) {
            KeyMap.Group.SPACE -> s.spaceInstrument
            KeyMap.Group.DIGIT -> s.digitInstrument
            KeyMap.Group.PUNCT -> s.punctInstrument
            else -> s.instrument
        }
        playWith(inst, ch, s)

        if (s.drumLayer) {
            val c = ch.lowercaseChar()
            when {
                group == KeyMap.Group.SPACE -> if (s.spaceInstrument != Instrument.DRUMS) engine.playDrum(Drum.KICK, 0.9f)
                c in "aeiou" -> engine.playDrum(Drum.HIHAT, 0.55f)
                group == KeyMap.Group.PUNCT -> engine.playDrum(Drum.SNARE, 0.8f)
                else -> Unit
            }
        }
        if (s.clickFx && group != KeyMap.Group.SPACE) engine.playDrum(Drum.CLAVE, 0.25f)
    }

    private fun playWith(inst: Instrument, ch: Char, s: MixerState) {
        when (inst) {
            Instrument.OFF -> Unit
            Instrument.DRUMS -> KeyMap.drumOf(ch)?.let { engine.playDrum(it) }
                ?: engine.playDrum(Drum.RIM, 0.7f)
            else -> {
                val deg = KeyMap.degreeOf(ch) ?: KeyMap.fallbackDegree(ch)
                val midi = s.scale.midi(s.baseMidi, deg)
                engine.playNote(inst, midi, if (ch.isUpperCase()) 1f else 0.85f)
            }
        }
    }
}
