package com.tejando.keyboard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.tejando.keyboard.ai.AiAction
import com.tejando.keyboard.ai.AiConfig
import com.tejando.keyboard.ai.AiConfigStore
import com.tejando.keyboard.ai.AiRegistry
import com.tejando.keyboard.ai.AiResult
import com.tejando.keyboard.ai.TRANSLATE_LANGS
import com.tejando.keyboard.audio.Drum
import com.tejando.keyboard.audio.Instrument
import com.tejando.keyboard.audio.KeyMap
import com.tejando.keyboard.audio.MixerState
import com.tejando.keyboard.audio.MixerStore
import com.tejando.keyboard.audio.Notes
import com.tejando.keyboard.audio.Scale
import com.tejando.keyboard.audio.SoundEngine
import com.tejando.keyboard.data.ClipboardStore
import com.tejando.keyboard.data.KeyboardPrefs
import com.tejando.keyboard.diag.Diagnostics
import com.tejando.keyboard.diag.Status
import com.tejando.keyboard.engine.UserWords
import com.tejando.keyboard.keyboard.KeyboardView
import com.tejando.keyboard.ui.Ui
import com.tejando.keyboard.vault.VaultActivity

/**
 * Configurações por categoria. Tudo é salvo na hora (SharedPreferences) e o teclado lê na
 * próxima vez que abrir, sem reiniciar o aparelho.
 */
class SettingsActivity : ComponentActivity() {

    private lateinit var prefs: KeyboardPrefs
    private lateinit var mixerStore: MixerStore
    private var mixer = MixerState()
    private val engine = SoundEngine()
    private var preview: KeyboardView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = KeyboardPrefs(this)
        mixerStore = MixerStore(this)
        mixer = mixerStore.load()
        engine.update(mixer)
        val cat = intent.getStringExtra(EXTRA_CAT) ?: "sound"
        val root = Ui.root(this)
        when (cat) {
            "size" -> sizeScreen(root)
            "sound" -> soundScreen(root)
            "scale" -> scaleScreen(root)
            "text" -> textScreen(root)
            "ai" -> aiScreen(root)
            "privacy" -> privacyScreen(root)
            "tests" -> testsScreen(root)
        }
        setContentView(Ui.screen(this, root))
    }

    override fun onDestroy() { engine.panic(); engine.stop(); super.onDestroy() }

    private fun save(m: MixerState) { mixer = m; mixerStore.save(m); engine.update(m) }

    // ------------------------------------------------------------------ tamanho

    private fun sizeScreen(r: LinearLayout) {
        r.addView(Ui.title(this, "Tamanho e proporções"))
        r.addView(Ui.note(this, "A prévia é o teclado de verdade. As mudanças valem na próxima vez que o teclado abrir."))
        val pv = KeyboardView(this).also { preview = it }
        pv.style = prefs.style()
        r.addView(pv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        fun upd() { pv.style = prefs.style() }
        r.addView(Ui.seek(this, "Altura das teclas (altura total)", 70, 150, prefs.heightPct, { "$it%" }) { prefs.heightPct = it; upd() })
        r.addView(Ui.seek(this, "Espaço entre teclas", 0, 10, prefs.gapDp, { "$it dp" }) { prefs.gapDp = it; upd() })
        r.addView(Ui.seek(this, "Largura do teclado", 60, 100, prefs.widthPct, { "$it%" }) { prefs.widthPct = it; upd() })
        r.addView(Ui.choice(this, "Posição (modo uma mão quando a largura é menor que 100%)", listOf(0, 1, 2), prefs.align,
            { listOf("Centro", "Esquerda", "Direita")[it] }) { prefs.align = it; upd() })
        r.addView(Ui.seek(this, "Largura das teclas de função (Shift, apagar, Enter)", 80, 180, prefs.fnPct, { "$it%" }) { prefs.fnPct = it; upd() })
        r.addView(Ui.button(this, "Restaurar tamanhos padrão", false) { prefs.resetSizes(); recreate() })
        r.addView(Ui.note(this, "Modo flutuante: não implementado nesta versão."))
    }

    // ------------------------------------------------------------------ sons / mixer

    private fun soundScreen(r: LinearLayout) {
        r.addView(Ui.title(this, "Sons, instrumentos e mixer"))
        r.addView(Ui.note(this, "Cada letra digita e toca uma nota. Estes ajustes são os mesmos do mixer escondido na aba !#1 do teclado."))
        r.addView(Ui.toggle(this, "Som ligado (digitação funciona com som desligado)", mixer.enabled) { save(mixer.copy(enabled = it)) })
        r.addView(Ui.seek(this, "Volume geral", 0, 100, mixer.volume, { "$it%" }) { save(mixer.copy(volume = it)) })

        r.addView(Ui.section(this, "INSTRUMENTO POR GRUPO DE TECLAS"))
        val all = Instrument.ALL
        fun inst(name: String, cur: Instrument, set: (Instrument) -> Unit) =
            Ui.choice(this, name, all, cur.ordinal, { it.label }) { set(it) }
        r.addView(inst("Letras", mixer.instrument) { save(mixer.copy(instrument = it)) })
        r.addView(inst("Números", mixer.digitInstrument) { save(mixer.copy(digitInstrument = it)) })
        r.addView(inst("Pontuação", mixer.punctInstrument) { save(mixer.copy(punctInstrument = it)) })
        r.addView(inst("Espaço", mixer.spaceInstrument) { save(mixer.copy(spaceInstrument = it)) })
        r.addView(Ui.toggle(this, "Bateria junto (espaço = bumbo, vogais = chimbal, pontuação = caixa)", mixer.drumLayer) { save(mixer.copy(drumLayer = it)) })
        r.addView(Ui.seek(this, "Volume da bateria", 0, 100, mixer.drumVolume, { "$it%" }) { save(mixer.copy(drumVolume = it)) })
        r.addView(Ui.toggle(this, "Clique mecânico extra (Enter/apagar e um clique em cada tecla)", mixer.clickFx) { save(mixer.copy(clickFx = it)) })

        r.addView(Ui.section(this, "TIMBRE E EFEITOS"))
        r.addView(Ui.seek(this, "Duração das notas", 0, 100, mixer.noteLen, { "$it%" }) { save(mixer.copy(noteLen = it)) })
        r.addView(Ui.seek(this, "Eco (delay)", 0, 100, mixer.echo, { "$it%" }) { save(mixer.copy(echo = it)) })
        r.addView(Ui.seek(this, "Reverberação", 0, 100, mixer.reverb, { "$it%" }) { save(mixer.copy(reverb = it)) })
        r.addView(Ui.seek(this, "Distorção (drive)", 0, 100, mixer.drive, { "$it%" }) { save(mixer.copy(drive = it)) })
        r.addView(Ui.seek(this, "Brilho (filtro)", 0, 100, mixer.tone, { "$it%" }) { save(mixer.copy(tone = it)) })
        r.addView(Ui.seek(this, "Andamento do eco (BPM)", 40, 200, mixer.bpm, { "$it" }) { save(mixer.copy(bpm = it)) })

        r.addView(Ui.section(this, "OUVIR"))
        r.addView(Ui.button(this, "Tocar uma escala com o instrumento das letras") { playScale() })
        r.addView(Ui.button(this, "Tocar bateria", false) { playDrums() })
        r.addView(Ui.note(this, "Os instrumentos são sintetizados no aparelho, sem arquivos de áudio e sem internet."))
        r.addView(Ui.section(this, "TESTAR DIGITANDO DE VERDADE (precisa do Tejando como teclado ativo)"))
        r.addView(EditText(this).apply { hint = "Toque aqui e digite"; setTextColor(Ui.FG); setHintTextColor(Ui.MUTED) })
        r.addView(Ui.button(this, "Restaurar mixer padrão", false) { save(mixerStore.reset()); recreate() })
    }

    private fun playScale() {
        if (!mixer.enabled) { Toast.makeText(this, "O som está desligado.", Toast.LENGTH_SHORT).show(); return }
        val inst = if (mixer.instrument == Instrument.OFF || mixer.instrument == Instrument.DRUMS) Instrument.PIANO else mixer.instrument
        engine.start()
        val h = android.os.Handler(mainLooper)
        for (i in 0..7) h.postDelayed({ engine.playNote(inst, mixer.scale.midi(mixer.baseMidi, i)) }, i * 260L)
    }

    private fun playDrums() {
        engine.start()
        val seq = listOf(Drum.KICK, Drum.HIHAT, Drum.SNARE, Drum.HIHAT, Drum.KICK, Drum.KICK, Drum.SNARE, Drum.CRASH)
        val h = android.os.Handler(mainLooper)
        seq.forEachIndexed { i, d -> h.postDelayed({ engine.playDrum(d) }, i * 220L) }
    }

    // ------------------------------------------------------------------ escalas / mapeamento

    private fun scaleScreen(r: LinearLayout) {
        r.addView(Ui.title(this, "Escalas, oitavas e mapeamento"))
        r.addView(Ui.note(this, "As letras viram graus da escala na ordem física do QWERTY (grave embaixo, agudo em cima). Escolha a escala e a tônica e a digitação soa coerente."))
        val table = TextView(this).apply { setTextColor(Ui.FG); textSize = 14f; typeface = android.graphics.Typeface.MONOSPACE }
        fun refresh() {
            fun row(chars: String) = chars.map { c ->
                val d = KeyMap.degreeOf(c)!!
                "${c.uppercaseChar()}=${Notes.label(mixer.scale.midi(mixer.baseMidi, d))}"
            }.joinToString("  ")
            table.text = "números: " + row("1234567890") + "\n\nq-p:  " + row("qwertyuiop") + "\n\na-l:  " + row("asdfghjkl") + "\n\nz-m:  " + row("zxcvbnm")
        }
        r.addView(Ui.choice(this, "Escala", Scale.values().toList(), mixer.scale.ordinal, { it.label }) { save(mixer.copy(scale = it)); refresh() })
        r.addView(Ui.choice(this, "Tonalidade (tônica)", (0..11).toList(), mixer.root, { Notes.NAMES[it] }) { save(mixer.copy(root = it)); refresh() })
        r.addView(Ui.seek(this, "Oitava base", 1, 6, mixer.octave, { "$it" }) { save(mixer.copy(octave = it)); refresh() })
        r.addView(Ui.section(this, "MAPA ATUAL: TECLA = NOTA"))
        r.addView(table)
        refresh()
        r.addView(Ui.button(this, "Ouvir a escala") { playScale() })
        r.addView(Ui.note(this, "Mapeamento individual tecla a tecla ainda não é editável; o mapa muda pela escala, tônica e oitava."))
    }

    // ------------------------------------------------------------------ sugestões

    private fun textScreen(r: LinearLayout) {
        r.addView(Ui.title(this, "Sugestões e correção"))
        r.addView(Ui.toggle(this, "Sugestões de palavras", prefs.suggestions) { prefs.suggestions = it })
        r.addView(Ui.toggle(this, "Aprender minhas palavras (guardado só neste aparelho)", prefs.learnWords) { prefs.learnWords = it })
        r.addView(Ui.note(this, "Palavras aprendidas: ${UserWords(this).count()}. Campos de senha, e-mail e URL nunca são usados para aprender."))
        r.addView(Ui.button(this, "Apagar vocabulário aprendido", false) { UserWords(this).clear(); recreate() })
        r.addView(Ui.section(this, "MODOS DE CORREÇÃO (na barra ✦ do teclado)"))
        r.addView(Ui.note(this, "Corrigir (local, sem internet): arruma espaços e maiúsculas sem mudar o seu jeito de escrever.\n\nIA ▾: Corrigir IA, Reescrever, Resumir, Organizar, Explicar e Continuar. Só rodam quando você toca, só enviam o texto selecionado (ou a última linha) e mostram o resultado antes de aplicar.\n\n\"Manter meu jeito\" é a regra do Corrigir: não formaliza, preserva gírias e tom."))
    }

    // ------------------------------------------------------------------ IA

    private fun aiScreen(r: LinearLayout) {
        val store = AiConfigStore(this)
        val cur = store.load()
        r.addView(Ui.title(this, "Provedores de IA e tradução"))
        r.addView(Ui.note(this, "Tradução e IA usam INTERNET e um provedor com chave de API. Nada é enviado sem você tocar numa ação. Assinaturas do ChatGPT ou do Gemini NÃO dão acesso à API: a API é uma conta separada, com cobrança por uso, criada no site do provedor."))
        r.addView(Ui.choice(this, "Provedor", AiRegistry.providers, 0, { it.displayName }) { })
        val url = Ui.edit(this, "Endereço da API (termina em /v1)", cur.baseUrl)
        val model = Ui.edit(this, "Modelo", cur.model)
        val key = Ui.edit(this, if (cur.apiKey.isNotEmpty()) "Chave salva (deixe vazio para manter)" else "Chave de API", "", password = true)
        r.addView(url); r.addView(model); r.addView(key)
        val result = Ui.note(this, "")
        fun current(): Pair<AiConfig, Boolean> {
            val changed = key.text.toString().isNotBlank()
            return AiConfig("openai", url.text.toString(), model.text.toString(), if (changed) key.text.toString() else cur.apiKey) to changed
        }
        r.addView(Ui.button(this, "Salvar") {
            val (c, ch) = current(); store.save(c, ch); key.setText(""); result.text = "Salvo. A chave fica cifrada com o Android Keystore."
        })
        r.addView(Ui.button(this, "Testar conexão", false) {
            val (c, ch) = current(); store.save(c, ch)
            result.text = "Testando…"
            com.tejando.keyboard.ai.AiRunner.run(this, AiAction.EXPLAIN, "ok", "responda apenas: pronto") {
                result.text = when (it) { is AiResult.Ok -> "Conexão OK: ${it.text.take(60)}"; is AiResult.Fail -> "Falhou: ${it.message}" }
            }
        })
        r.addView(result)
        r.addView(Ui.section(this, "TRADUÇÃO"))
        r.addView(Ui.choice(this, "Idioma de destino", TRANSLATE_LANGS, TRANSLATE_LANGS.indexOfFirst { it.first == prefs.translateTarget }.coerceAtLeast(0), { it.second }) { prefs.translateTarget = it.first })
        r.addView(Ui.note(this, "Exemplos de endereço: OpenAI https://api.openai.com/v1 · OpenRouter https://openrouter.ai/api/v1 · Ollama local http://IP:11434/v1. Tradução offline (download de modelo) não está implementada. Gemini e Claude usam protocolos próprios: precisam de um novo provedor em ai/Ai.kt."))
    }

    // ------------------------------------------------------------------ privacidade

    private fun privacyScreen(r: LinearLayout) {
        r.addView(Ui.title(this, "Privacidade, cofre e dados"))
        r.addView(Ui.toggle(this, "Modo privado (sem aprender palavras, sem IA, sem histórico de cópia, sem emojis recentes)", prefs.privateMode) { prefs.privateMode = it })
        r.addView(Ui.toggle(this, "Sem som em campos de senha", prefs.muteInPasswords) { prefs.muteInPasswords = it })
        r.addView(Ui.section(this, "COFRE DE SENHAS"))
        r.addView(Ui.note(this, "Guarde senhas, e-mails e outros dados. Cada item é cifrado e só abre com a digital. No teclado: ✦ > Cofre."))
        r.addView(Ui.button(this, "Abrir cofre") { startActivity(Intent(this, VaultActivity::class.java)) })
        r.addView(Ui.section(this, "ÁREA DE TRANSFERÊNCIA"))
        r.addView(Ui.button(this, "Apagar todo o histórico (inclusive fixados)", false) { ClipboardStore(this).clearAll(); Toast.makeText(this, "Apagado.", Toast.LENGTH_SHORT).show() })
        r.addView(Ui.section(this, "O QUE O APP FAZ"))
        r.addView(Ui.note(this, "Permissões: INTERNET (só para IA/tradução, quando você toca) e biometria (só para o cofre). Sem microfone, sem contatos, sem localização.\n\nSenhas e textos digitados não vão para logs. Nada é enviado automaticamente. O Android avisa que qualquer teclado pode ler o que você digita; isso é do sistema."))
    }

    // ------------------------------------------------------------------ testes

    private fun testsScreen(r: LinearLayout) {
        r.addView(Ui.title(this, "Testes e diagnóstico"))
        r.addView(Ui.note(this, "Roda no seu aparelho: gera áudio real, mede energia e frequência, e simula toques no teclado de verdade. Itens que dependem de ouvido, internet, chave ou digital aparecem como NÃO EXECUTADO."))
        val out = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val summary = Ui.note(this, "")
        r.addView(Ui.button(this, "Executar todos os testes") {
            out.removeAllViews(); summary.text = "Executando… (leva uns 3 s)"
            Diagnostics(this).runAll { list ->
                var p = 0; var f = 0; var s = 0
                list.forEach { t ->
                    when (t.status) { Status.PASS -> p++; Status.FAIL -> f++; Status.SKIP -> s++ }
                    val tag = when (t.status) { Status.PASS -> "✔ PASSOU"; Status.FAIL -> "✘ FALHOU"; Status.SKIP -> "– NÃO EXECUTADO" }
                    out.addView(TextView(this).apply {
                        text = "$tag · ${t.name}\n${t.detail}"
                        setTextColor(when (t.status) { Status.PASS -> 0xFF8FD18F.toInt(); Status.FAIL -> 0xFFFF7B72.toInt(); Status.SKIP -> Ui.MUTED })
                        textSize = 13f; setPadding(0, Ui.dp(this@SettingsActivity, 8), 0, 0)
                    })
                }
                summary.text = "$p passaram · $f falharam · $s não executados"
            }
        })
        r.addView(summary); r.addView(out)
    }

    companion object { const val EXTRA_CAT = "cat" }
}
