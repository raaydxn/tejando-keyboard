package com.tejando.keyboard.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.tejando.keyboard.security.CryptoBox
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Ações de texto. O prompt de sistema define o que a IA pode fazer; nada é enviado sem toque explícito. */
enum class AiAction(val label: String, val system: String) {
    FIX("Corrigir", "Corrija apenas ortografia, acentuação e pontuação. NÃO reescreva, NÃO formalize, preserve gírias, abreviações, ironia, tom e palavrões. Não altere nomes, números nem fatos. Responda somente com o texto corrigido."),
    TRANSLATE("Traduzir", "Traduza o texto para o idioma pedido. Preserve o tom. Responda somente com a tradução."),
    REWRITE("Reescrever", "Reescreva o texto de forma mais clara, mantendo o significado e sem inventar informações. Responda somente com o texto reescrito."),
    SUMMARIZE("Resumir", "Resuma o texto mantendo as informações essenciais. Responda somente com o resumo."),
    ORGANIZE("Organizar", "Melhore a estrutura do texto preservando exatamente o sentido e o tom. Não acrescente informações. Responda somente com o texto organizado."),
    EXPLAIN("Explicar", "Explique de forma simples o que o texto significa. Seja breve."),
    CONTINUE("Continuar", "Sugira uma continuação natural para o texto, no mesmo tom e idioma. Responda somente com a continuação."),
}

sealed class AiResult {
    data class Ok(val text: String) : AiResult()
    data class Fail(val message: String) : AiResult()
}

/** Contrato de um provedor. Novos provedores implementam isto e entram em [AiRegistry]; o teclado não muda. */
interface AiProvider {
    val id: String
    val displayName: String
    fun complete(system: String, user: String, config: AiConfig): AiResult
}

data class AiConfig(val providerId: String, val baseUrl: String, val model: String, val apiKey: String) {
    val isUsable get() = baseUrl.isNotBlank() && model.isNotBlank()
}

/** Qualquer serviço que fale o protocolo "chat/completions" da OpenAI (OpenAI, OpenRouter, Groq, Ollama, LM Studio...). */
class OpenAiCompatibleProvider : AiProvider {
    override val id = "openai"
    override val displayName = "OpenAI / compatível"

    override fun complete(system: String, user: String, config: AiConfig): AiResult {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(config.baseUrl.trimEnd('/') + "/chat/completions")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10_000
                readTimeout = 45_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                if (config.apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer ${config.apiKey}")
            }
            val body = JSONObject()
                .put("model", config.model)
                .put("temperature", 0.3)
                .put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user)))
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            when {
                code in 200..299 -> {
                    val out = JSONObject(text).getJSONArray("choices").getJSONObject(0)
                        .getJSONObject("message").getString("content").trim()
                    if (out.isEmpty()) AiResult.Fail("A IA devolveu uma resposta vazia.") else AiResult.Ok(out)
                }
                code == 401 || code == 403 -> AiResult.Fail("Chave de API recusada (HTTP $code). Confira a chave e a conta.")
                code == 429 -> AiResult.Fail("Limite de uso ou cota esgotada (HTTP 429). Verifique o plano/cobrança do provedor.")
                else -> AiResult.Fail("Erro do serviço (HTTP $code). ${apiMessage(text)}")
            }
        } catch (e: java.net.UnknownHostException) {
            AiResult.Fail("Sem conexão com a internet ou endereço inválido.")
        } catch (e: java.net.SocketTimeoutException) {
            AiResult.Fail("O serviço demorou demais para responder.")
        } catch (e: Exception) {
            AiResult.Fail("Falha: ${e.javaClass.simpleName}")
        } finally {
            conn?.disconnect()
        }
    }

    private fun apiMessage(body: String): String = try {
        JSONObject(body).getJSONObject("error").getString("message").take(160)
    } catch (_: Exception) { "" }
}

object AiRegistry {
    val providers: List<AiProvider> = listOf(OpenAiCompatibleProvider())
    fun get(id: String): AiProvider = providers.firstOrNull { it.id == id } ?: providers.first()
}

/** Configuração salva localmente. A chave de API fica cifrada com o Android Keystore. Nunca vai no código nem no APK. */
class AiConfigStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("tejando_ai", Context.MODE_PRIVATE)

    fun load() = AiConfig(
        providerId = sp.getString("provider", "openai") ?: "openai",
        baseUrl = sp.getString("base_url", "https://api.openai.com/v1") ?: "",
        model = sp.getString("model", "gpt-4o-mini") ?: "",
        apiKey = sp.getString("key", null)?.let { CryptoBox.decryptPlain(it) } ?: "",
    )

    fun save(c: AiConfig, keyChanged: Boolean) {
        val e = sp.edit().putString("provider", c.providerId).putString("base_url", c.baseUrl.trim()).putString("model", c.model.trim())
        if (keyChanged) {
            if (c.apiKey.isBlank()) e.remove("key") else e.putString("key", CryptoBox.encryptPlain(c.apiKey.trim()))
        }
        e.apply()
    }
}

object AiRunner {
    private val main = Handler(Looper.getMainLooper())

    fun run(context: Context, action: AiAction, text: String, extra: String?, cb: (AiResult) -> Unit) {
        val cfg = AiConfigStore(context).load()
        if (!cfg.isUsable) { cb(AiResult.Fail("IA não configurada. Abra o app Tejando Keyboard Music > Provedores de IA.")); return }
        val system = action.system + (if (extra != null) " Idioma/instrução: $extra." else "")
        Thread {
            val r = AiRegistry.get(cfg.providerId).complete(system, text, cfg)
            main.post { cb(r) }
        }.start()
    }
}

val TRANSLATE_LANGS = listOf(
    "en" to "English", "es" to "Español", "fr" to "Français", "de" to "Deutsch", "it" to "Italiano",
    "pt" to "Português", "ja" to "日本語", "zh" to "中文", "ko" to "한국어", "ru" to "Русский",
)
