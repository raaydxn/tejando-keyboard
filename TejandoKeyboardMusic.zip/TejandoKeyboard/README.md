# Tejando Keyboard Music

Teclado Android (IME) em Kotlin: um QWERTY musical. Cada letra insere o texto normalmente e, no mesmo toque, toca uma nota.
Base: o projeto TejandoKeyboard enviado (layout Canvas, multitoque, acentos, papel de parede, sugestões).
Sons: sintetizador próprio portado do `grok-workspace` (que era Web Audio, sem samples), reescrito em Kotlin sobre AudioTrack.

## Compilar
**GitHub Actions (recomendado):** suba esta pasta para um repositório; o workflow `.github/workflows/build-apk.yml` gera o artefato `app-debug.apk`.
**Android Studio:** File > Open nesta pasta, aguarde o Gradle (8.7, precisa de internet), Build > Build APK(s).
O wrapper (`gradlew`) não vem no ZIP. Gere com `gradle wrapper --gradle-version 8.7` se quiser usar o terminal.

## Instalar e ativar
1. Instale o APK. 2. Abra **Tejando Keyboard Music** > *Abrir ajustes de teclado* e ligue o teclado. 3. *Escolher teclado* e selecione-o.
4. Para o mixer: no teclado, toque em `!#1` e depois em **♪ MIX** (ao lado da vírgula).

## Como funciona o som
- `audio/SoundEngine.kt`: thread de render + AudioTrack baixa latência, 24 vozes, eco, reverb, drive, filtro.
- `audio/Dsp.kt`: osciladores, corda (Karplus-Strong), piano aditivo, baixo, 15 peças de bateria (receitas do Grok).
- `audio/Music.kt`: escalas e mapeamento tecla > grau da escala. `audio/KeySounds.kt`: liga teclas aos instrumentos.
- O som dispara no instante do toque; o texto entra quando o dedo solta. Áudio mudo ou com erro nunca bloqueia a digitação.
- Sem samples e sem internet. Latência varia por aparelho e não foi medida em hardware.

## Estrutura
`TejandoKeyboardService` (IME) · `keyboard/` (layout e view) · `audio/` · `ai/` (provedores) · `vault/` (cofre com digital) ·
`security/CryptoBox` (Keystore) · `diag/Diagnostics` (testes no aparelho) · `SettingsActivity` · `MainActivity`.

## Privacidade
INTERNET só para IA/tradução, sob toque do usuário. Biometria só para o cofre. Chave de API cifrada no Keystore, nunca no código.
Sem som em campos de senha (opção). Modo privado desliga aprendizado, IA, histórico de cópia e emojis recentes.

## Limitações conhecidas
Ver o relatório final entregue junto. Não implementados: ditado por voz, GIFs, cursor pela barra de espaço, desfazer/refazer,
modo flutuante, busca de emojis, tradução offline, mapeamento tecla a tecla editável, Autofill.
