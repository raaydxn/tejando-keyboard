# Tejando Keyboard

Teclado Android (IME) em Kotlin, sem Compose e sem bibliotecas pesadas.

- QWERTY PT-BR no estilo Samsung/Gboard, com número como dica no canto das teclas da primeira fileira
- Toque longo nas vogais, `c` e `n` abre os acentos (á à â ã ç ñ...). Toque longo no `.` abre pontuação
- Shift (uma letra), toque duplo = Caps Lock, auto-maiúscula no começo de frases
- Símbolos (`?123`), mais símbolos (`=\<`), emojis, espaço, apagar (com repetição) e Enter
- O Enter muda de rótulo conforme o campo (Ir, Buscar, Enviar, Próx., OK)
- Papel de parede escolhido na galeria, com ajuste de escurecimento, opacidade das teclas e posição da imagem
- Barra de sugestões de palavras (por prefixo, ignora acentos) e botão ✦ reservado para IA
- Duplo espaço vira ". ", toque longo no espaço abre o seletor de teclado, vibração opcional

`minSdk 26` (Android 8.0+), `compileSdk/targetSdk 34`.

## Compilar o APK

1. Android Studio: **File > Open** e escolha a pasta `TejandoKeyboard`.
2. Espere o Gradle sincronizar (baixa o Gradle 8.7 e as dependências; precisa de internet).
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK fica em `app/build/outputs/apk/debug/app-debug.apk`. Ele já vem assinado com a chave de debug e instala direto.

Se quiser rodar `./gradlew` no terminal, gere o wrapper uma vez com `gradle wrapper --gradle-version 8.7`.
O wrapper (`gradlew` e o `.jar`) não vem no ZIP; o Android Studio não precisa dele pra sincronizar.

O build **release** sai sem assinatura e não instala. Para distribuir, use **Build > Generate Signed Bundle / APK**.

## Ativar no celular

1. Abra o app **Tejando Keyboard** e toque em *Abrir ajustes de teclado*. Ligue o Tejando na lista.
2. Volte ao app e toque em *Escolher teclado*. Selecione o Tejando.
3. Em *Visual*, toque em *Escolher da galeria*. A prévia mostra o teclado de verdade, com os sliders ao vivo.
4. Teste no campo de baixo.

O Android mostra um aviso de que qualquer teclado pode ler o que você digita. É padrão do sistema.
Este teclado **não pede permissão de internet** e não envia nada pra lugar nenhum.

## Estrutura

```
app/src/main/java/com/tejando/keyboard/
├── TejandoKeyboardService.kt     o IME: recebe as teclas e escreve no app em foco
├── MainActivity.kt               ativação, galeria, ajustes e prévia
├── keyboard/
│   ├── KeyboardLayouts.kt        TODAS as teclas, acentos e emojis ficam aqui
│   └── KeyboardView.kt           desenho no Canvas, multitoque, popups, shift
├── data/
│   ├── KeyboardPrefs.kt          preferências (SharedPreferences)
│   └── WallpaperStore.kt         copia e reduz a imagem da galeria p/ filesDir
└── engine/
    ├── SuggestionEngine.kt       interface de sugestões
    ├── LocalSuggestionEngine.kt  implementação por prefixo (res/raw/palavras_pt.txt)
    └── AiAssistant.kt            interface para IA (hoje NoOp)
```

## Como evoluir

- **Mais emojis ou outra linguagem:** edite `KeyboardLayouts.kt`. A camada `EMOJI` é uma lista simples.
  Para muitas categorias e rolagem, o próximo passo é uma grade rolável em vez de teclas fixas.
- **Sugestões melhores:** implemente `SuggestionEngine` (bigramas, aprendizado do que o usuário digita,
  modelo on-device) e troque em `TejandoKeyboardService`. A lista atual tem ~490 palavras, serve de demonstração.
- **IA:** implemente `AiAssistant`. O botão ✦ já chama `onInvoke(textoAntesDoCursor)`.
  Vai precisar de permissão `INTERNET`, chamada assíncrona e um jeito do usuário informar a chave de API.
  Cuidado com campos de senha: o serviço já evita sugestões neles, faça o mesmo para IA.
- **Outra altura/estilo de tecla:** `computeMetrics()` e `drawKey()` em `KeyboardView.kt`.

## Limitações conhecidas

- Sem corretor ortográfico, sem digitação por deslize (swipe) e sem sugestão de próxima palavra.
- Emojis: só 24 fixos.
- Altura do teclado fixa (não tem opção de ajuste ainda).
- Sem sons de tecla.

## Sobre o `grok-workspace.zip`

O arquivo enviado é um app web (React/Vite) de um teclado musical. Não tem código Android nem de IME.
Usei só a paleta de cores dele (fundo `#14120E`, tecla `#1E1B16`, destaque laranja `#E8893A`).
