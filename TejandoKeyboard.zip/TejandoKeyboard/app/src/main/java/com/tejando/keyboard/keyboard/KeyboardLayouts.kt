package com.tejando.keyboard.keyboard

/** Camadas do teclado. */
enum class Layer { LETTERS, SYMBOLS, SYMBOLS_2, EMOJI }

/** Estado do Shift: desligado, uma letra (ONCE) ou Caps Lock (CAPS). */
enum class ShiftState { OFF, ONCE, CAPS }

enum class KeyType { CHAR, SHIFT, DELETE, ENTER, SPACE, SWITCH_LAYER, EMOJI_TOGGLE, SPACER }

/**
 * Uma tecla do layout.
 *
 * @param label       texto mostrado e, para teclas CHAR, texto digitado.
 * @param weight      largura relativa dentro da linha.
 * @param hint        dica pequena no canto da tecla (ex.: o número da fileira de cima);
 *                    também é digitada no toque longo.
 * @param alternates  variantes mostradas no toque longo (acentos etc.).
 * @param targetLayer camada para onde teclas SWITCH_LAYER / EMOJI_TOGGLE levam.
 */
data class Key(
    val label: String,
    val type: KeyType = KeyType.CHAR,
    val weight: Float = 1f,
    val hint: String? = null,
    val alternates: List<String> = emptyList(),
    val targetLayer: Layer? = null,
) {
    /** Itens do popup de toque longo: acentos primeiro, dica (número) por último. */
    val popupItems: List<String>
        get() = buildList {
            addAll(alternates)
            hint?.let { add(it) }
        }
}

/**
 * Todos os layouts do teclado ficam aqui. Para mudar teclas, acentos ou a lista de
 * emojis, é só editar este arquivo.
 */
object KeyboardLayouts {

    fun rows(layer: Layer): List<List<Key>> = when (layer) {
        Layer.LETTERS -> LETTERS
        Layer.SYMBOLS -> SYMBOLS
        Layer.SYMBOLS_2 -> SYMBOLS_2
        Layer.EMOJI -> EMOJI
    }

    private val ACCENTS = mapOf(
        "a" to listOf("á", "à", "â", "ã", "ä"),
        "e" to listOf("é", "ê", "è", "ë"),
        "i" to listOf("í", "î", "ì", "ï"),
        "o" to listOf("ó", "ô", "õ", "ò", "ö"),
        "u" to listOf("ú", "ü", "ù", "û"),
        "c" to listOf("ç"),
        "n" to listOf("ñ"),
    )

    private fun letterRow(letters: String, digits: String? = null): List<Key> =
        letters.mapIndexed { i, ch ->
            val s = ch.toString()
            Key(
                label = s,
                hint = digits?.getOrNull(i)?.toString(),
                alternates = ACCENTS[s].orEmpty(),
            )
        }

    private fun charRow(chars: String): List<Key> = chars.map { Key(it.toString()) }

    private fun emojiRow(vararg emojis: String): List<Key> = emojis.map { Key(it) }

    private fun spacer(weight: Float) = Key("", KeyType.SPACER, weight)

    private fun shiftKey() = Key("shift", KeyType.SHIFT, 1.5f)
    private fun deleteKey() = Key("delete", KeyType.DELETE, 1.5f)

    private fun bottomRow(switchLabel: String, switchTo: Layer): List<Key> = listOf(
        Key(switchLabel, KeyType.SWITCH_LAYER, 1.5f, targetLayer = switchTo),
        Key(","),
        Key("emoji", KeyType.EMOJI_TOGGLE, 1f, targetLayer = Layer.EMOJI),
        Key(" ", KeyType.SPACE, 4f),
        Key(".", alternates = listOf("?", "!", ":", ";", "…", "-")),
        Key("enter", KeyType.ENTER, 1.5f),
    )

    private val LETTERS: List<List<Key>> = listOf(
        letterRow("qwertyuiop", "1234567890"),
        listOf(spacer(0.5f)) + letterRow("asdfghjkl") + listOf(spacer(0.5f)),
        listOf(shiftKey()) + letterRow("zxcvbnm") + listOf(deleteKey()),
        bottomRow("?123", Layer.SYMBOLS),
    )

    private val SYMBOLS: List<List<Key>> = listOf(
        charRow("1234567890"),
        charRow("@#\$_&-+()/"),
        listOf(Key("=\\<", KeyType.SWITCH_LAYER, 1.5f, targetLayer = Layer.SYMBOLS_2)) +
            charRow("*\"':;!?") + listOf(deleteKey()),
        bottomRow("ABC", Layer.LETTERS),
    )

    private val SYMBOLS_2: List<List<Key>> = listOf(
        charRow("~`|•√π÷×<>"),
        charRow("£¢€¥^°={}\\"),
        listOf(Key("?123", KeyType.SWITCH_LAYER, 1.5f, targetLayer = Layer.SYMBOLS)) +
            charRow("%©®™[]¶") + listOf(deleteKey()),
        bottomRow("ABC", Layer.LETTERS),
    )

    private val EMOJI: List<List<Key>> = listOf(
        emojiRow("😀", "😂", "😅", "😊", "😍", "😘", "😎", "🤔"),
        emojiRow("😢", "😭", "😡", "🥳", "😴", "🙄", "😉", "🤗"),
        emojiRow("👍", "👏", "🙏", "💪", "🔥", "❤️", "✨", "🎉"),
        listOf(
            Key("ABC", KeyType.SWITCH_LAYER, 1.5f, targetLayer = Layer.LETTERS),
            Key(" ", KeyType.SPACE, 5f),
            deleteKey(),
        ),
    )
}
