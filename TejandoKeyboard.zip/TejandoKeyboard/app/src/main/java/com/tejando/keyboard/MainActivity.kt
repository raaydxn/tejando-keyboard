package com.tejando.keyboard

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import com.tejando.keyboard.data.KeyboardPrefs
import com.tejando.keyboard.data.WallpaperStore
import com.tejando.keyboard.keyboard.KeyboardView

/**
 * Tela de configuração: guia pra ativar o teclado, escolher o papel de parede
 * na galeria e ajustar o visual, com uma prévia ao vivo do teclado de verdade.
 */
class MainActivity : ComponentActivity() {

    private lateinit var prefs: KeyboardPrefs
    private lateinit var preview: KeyboardView
    private lateinit var stepEnableTitle: TextView
    private lateinit var stepSelectTitle: TextView
    private lateinit var btnSelect: Button
    private lateinit var dimLabel: TextView
    private lateinit var keysLabel: TextView
    private lateinit var focusLabel: TextView

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) importWallpaper(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = KeyboardPrefs(this)

        preview = findViewById(R.id.preview)
        stepEnableTitle = findViewById(R.id.stepEnableTitle)
        stepSelectTitle = findViewById(R.id.stepSelectTitle)
        btnSelect = findViewById(R.id.btnSelect)
        dimLabel = findViewById(R.id.dimLabel)
        keysLabel = findViewById(R.id.keysLabel)
        focusLabel = findViewById(R.id.focusLabel)

        findViewById<Button>(R.id.btnEnable).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        btnSelect.setOnClickListener {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
        findViewById<Button>(R.id.btnPick).setOnClickListener {
            pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        findViewById<Button>(R.id.btnRemove).setOnClickListener {
            WallpaperStore.clear(this)
            preview.setWallpaper(null)
        }

        findViewById<SeekBar>(R.id.seekDim).apply {
            progress = prefs.dim.coerceIn(0, 80)
            onProgress { prefs.dim = it; refreshStyle() }
        }
        findViewById<SeekBar>(R.id.seekKeys).apply {
            progress = (prefs.keyOpacity - 20).coerceIn(0, 80)
            onProgress { prefs.keyOpacity = it + 20; refreshStyle() }
        }
        findViewById<SeekBar>(R.id.seekFocus).apply {
            progress = prefs.focusY.coerceIn(0, 100)
            onProgress { prefs.focusY = it; refreshStyle() }
        }
        findViewById<Switch>(R.id.switchHaptic).apply {
            isChecked = prefs.haptic
            setOnCheckedChangeListener { _, checked -> prefs.haptic = checked; refreshStyle() }
        }
        findViewById<Switch>(R.id.switchSuggestions).apply {
            isChecked = prefs.suggestions
            setOnCheckedChangeListener { _, checked -> prefs.suggestions = checked }
        }

        preview.setWallpaper(WallpaperStore.load(this))
        refreshStyle()
    }

    override fun onResume() {
        super.onResume()
        updateSteps()
    }

    private fun refreshStyle() {
        preview.style = prefs.style()
        dimLabel.text = getString(R.string.label_dim, prefs.dim)
        keysLabel.text = getString(R.string.label_keys, prefs.keyOpacity)
        focusLabel.text = getString(R.string.label_focus, prefs.focusY)
    }

    private fun updateSteps() {
        val enabled = isKeyboardEnabled()
        val selected = isKeyboardSelected()
        stepEnableTitle.text = getString(R.string.step_enable) + (if (enabled) "  ✓" else "")
        stepSelectTitle.text = getString(R.string.step_select) + (if (selected) "  ✓" else "")
        btnSelect.isEnabled = enabled
        btnSelect.alpha = if (enabled) 1f else 0.4f
    }

    private fun isKeyboardEnabled(): Boolean {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.any { it.packageName == packageName }
    }

    private fun isKeyboardSelected(): Boolean {
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?: return false
        return current.startsWith("$packageName/")
    }

    private fun importWallpaper(uri: Uri) {
        Thread {
            val ok = WallpaperStore.importFrom(applicationContext, uri)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (ok) {
                    preview.setWallpaper(WallpaperStore.load(this))
                } else {
                    Toast.makeText(this, R.string.wallpaper_error, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun SeekBar.onProgress(block: (Int) -> Unit) {
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) block(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }
}
