package com.tejando.keyboard

import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import com.tejando.keyboard.data.KeyboardPrefs
import com.tejando.keyboard.data.WallpaperStore
import com.tejando.keyboard.engine.AiAssistant
import com.tejando.keyboard.engine.LocalSuggestionEngine
import com.tejando.keyboard.engine.NoOpAiAssistant
import com.tejando.keyboard.engine.SuggestionEngine
import com.tejando.keyboard.engine.currentWordPrefix
import com.tejando.keyboard.keyboard.KeyboardView
import com.tejando.keyboard.keyboard.Layer

/**
 * O teclado em si. O Android liga este serviço quando o usuário seleciona o
 * Tejando Keyboard; ele devolve o [KeyboardView] em [onCreateInputView] e recebe os
 * toques via [KeyboardView.Listener], escrevendo no app em foco pelo InputConnection.
 */
class TejandoKeyboardService : InputMethodService(), KeyboardView.Listener {

    private var keyboardView: KeyboardView? = null
    private lateinit var prefs: KeyboardPrefs

    // Pontos de extensão: troque as implementações aqui.
    private val suggestionEngine: SuggestionEngine by lazy { LocalSuggestionEngine(applicationContext) }
    private val aiAssistant: AiAssistant = NoOpAiAssistant()

    override fun onCreate() {
        super.onCreate()
        prefs = KeyboardPrefs(this)
    }

    override fun onCreateInputView(): View {
        val view = KeyboardView(this)
        view.listener = this
        keyboardView = view
        applyStyle()
        return view
    }

    // Sem o modo "tela cheia" de extração no modo paisagem.
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val view = keyboardView ?: return
        applyStyle()
        view.setEnterLabel(enterLabel(info))
        view.setLayer(initialLayer(info))
        view.resetShift()
        refreshState()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int,
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        refreshState()
    }

    override fun onDestroy() {
        keyboardView?.listener = null
        keyboardView = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- KeyboardView.Listener

    override fun onText(text: String) {
        val ic = currentInputConnection ?: return
        if (text == " " && shouldAutoPeriod(ic)) {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
            ic.endBatchEdit()
        } else {
            ic.commitText(text, 1)
        }
        refreshState()
    }

    override fun onDelete() {
        if (currentInputConnection == null) return
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        refreshState()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        val options = info?.imeOptions ?: 0
        val action = options and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (options and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (info == null || noEnterAction ||
            action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            ic.performEditorAction(action)
        }
        refreshState()
    }

    override fun onInputMethodPicker() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showInputMethodPicker()
    }

    override fun onSuggestionPicked(word: String) {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(40, 0)?.toString().orEmpty()
        val prefix = currentWordPrefix(before)
        ic.beginBatchEdit()
        if (prefix.isNotEmpty()) ic.deleteSurroundingText(prefix.length, 0)
        ic.commitText("$word ", 1)
        ic.endBatchEdit()
        refreshState()
    }

    override fun onAiClicked() {
        if (!aiAssistant.isConfigured) {
            Toast.makeText(this, R.string.ai_not_configured, Toast.LENGTH_SHORT).show()
            return
        }
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(500, 0)?.toString().orEmpty()
        aiAssistant.onInvoke(before)?.let { ic.commitText(it, 1) }
        refreshState()
    }

    // ---------------------------------------------------------------- estado

    private fun applyStyle() {
        val view = keyboardView ?: return
        view.style = prefs.style()
        view.setWallpaper(WallpaperStore.load(this))
    }

    private fun refreshState() {
        updateShiftFromEditor()
        updateSuggestions()
    }

    private fun updateShiftFromEditor() {
        val view = keyboardView ?: return
        val info = currentInputEditorInfo ?: return
        val ic = currentInputConnection ?: return
        val capitalize = info.inputType != InputType.TYPE_NULL && ic.getCursorCapsMode(info.inputType) != 0
        view.autoShift(capitalize)
    }

    private fun updateSuggestions() {
        val view = keyboardView ?: return
        val info = currentInputEditorInfo
        val ic = currentInputConnection
        if (!prefs.suggestions || info == null || ic == null || !isPlainTextField(info)) {
            view.setSuggestions(emptyList())
            return
        }
        val before = ic.getTextBeforeCursor(40, 0)?.toString().orEmpty()
        view.setSuggestions(suggestionEngine.suggest(before))
    }

    /** Duplo espaço vira ". " (depois de letra ou número), como no Gboard. */
    private fun shouldAutoPeriod(ic: android.view.inputmethod.InputConnection): Boolean {
        val info = currentInputEditorInfo ?: return false
        if (!isPlainTextField(info)) return false
        val before = ic.getTextBeforeCursor(2, 0)?.toString().orEmpty()
        return before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()
    }

    /** Texto "normal": não é número/telefone, senha, e-mail nem URL. */
    private fun isPlainTextField(info: EditorInfo): Boolean {
        val type = info.inputType
        if ((type and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return false
        if ((type and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) return false
        return when (type and InputType.TYPE_MASK_VARIATION) {
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_URI -> false
            else -> true
        }
    }

    private fun initialLayer(info: EditorInfo): Layer =
        when (info.inputType and InputType.TYPE_MASK_CLASS) {
            InputType.TYPE_CLASS_NUMBER,
            InputType.TYPE_CLASS_PHONE,
            InputType.TYPE_CLASS_DATETIME -> Layer.SYMBOLS
            else -> Layer.LETTERS
        }

    private fun enterLabel(info: EditorInfo): String? {
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return null
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> getString(R.string.enter_go)
            EditorInfo.IME_ACTION_SEARCH -> getString(R.string.enter_search)
            EditorInfo.IME_ACTION_SEND -> getString(R.string.enter_send)
            EditorInfo.IME_ACTION_NEXT -> getString(R.string.enter_next)
            EditorInfo.IME_ACTION_DONE -> getString(R.string.enter_done)
            else -> null
        }
    }
}
