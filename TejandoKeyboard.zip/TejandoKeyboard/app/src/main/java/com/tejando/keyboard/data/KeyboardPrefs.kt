package com.tejando.keyboard.data

import android.content.Context

/** Parâmetros visuais usados pelo KeyboardView. */
data class KeyboardStyle(
    /** 0..90 — quanto escurecer o papel de parede. */
    val dim: Int = 35,
    /** 0..100 — opacidade das teclas. */
    val keyOpacity: Int = 65,
    /** 0..100 — posição vertical do recorte da imagem (0 = topo, 100 = base). */
    val focusY: Int = 50,
    val haptic: Boolean = true,
)

/** Preferências do teclado. Activity e Service rodam no mesmo processo e compartilham isto. */
class KeyboardPrefs(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("tejando_prefs", Context.MODE_PRIVATE)

    var dim: Int
        get() = sp.getInt(KEY_DIM, 35)
        set(value) = sp.edit().putInt(KEY_DIM, value).apply()

    var keyOpacity: Int
        get() = sp.getInt(KEY_OPACITY, 65)
        set(value) = sp.edit().putInt(KEY_OPACITY, value).apply()

    var focusY: Int
        get() = sp.getInt(KEY_FOCUS, 50)
        set(value) = sp.edit().putInt(KEY_FOCUS, value).apply()

    var haptic: Boolean
        get() = sp.getBoolean(KEY_HAPTIC, true)
        set(value) = sp.edit().putBoolean(KEY_HAPTIC, value).apply()

    var suggestions: Boolean
        get() = sp.getBoolean(KEY_SUGGESTIONS, true)
        set(value) = sp.edit().putBoolean(KEY_SUGGESTIONS, value).apply()

    fun style() = KeyboardStyle(dim, keyOpacity, focusY, haptic)

    private companion object {
        const val KEY_DIM = "dim"
        const val KEY_OPACITY = "key_opacity"
        const val KEY_FOCUS = "focus_y"
        const val KEY_HAPTIC = "haptic"
        const val KEY_SUGGESTIONS = "suggestions"
    }
}
