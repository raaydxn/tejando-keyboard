package com.tejando.keyboard.keyboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.util.AttributeSet
import android.util.SparseArray
import android.util.SparseIntArray
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import com.tejando.keyboard.data.KeyboardStyle
import kotlin.math.max

/**
 * Teclado desenhado à mão num Canvas: barra de sugestões em cima, teclas embaixo,
 * papel de parede no fundo. Suporta multitoque, toque longo (acentos), repetição do
 * apagar, Shift / Caps Lock e as camadas letras / símbolos / emojis.
 *
 * É um View comum: o mesmo componente é usado no serviço de teclado e na prévia
 * da tela de configurações.
 */
class KeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    interface Listener {
        fun onText(text: String)
        fun onDelete()
        fun onEnter()
        fun onInputMethodPicker()
        fun onSuggestionPicked(word: String)
        fun onAiClicked()
    }

    private class KeyRect(val key: Key, val cell: RectF, val draw: RectF)

    private class Popup(val items: List<String>, val rect: RectF, val itemW: Float, var selected: Int)

    private inner class PointerState(var keyRect: KeyRect) {
        var popup: Popup? = null
        var consumed = false
        var repeating = false
        val longPress = Runnable { onLongPress(this) }
        val repeat = object : Runnable {
            override fun run() {
                repeating = true
                listener?.onDelete()
                postDelayed(this, REPEAT_INTERVAL_MS)
            }
        }
    }

    var listener: Listener? = null

    var style: KeyboardStyle = KeyboardStyle()
        set(value) {
            field = value
            invalidate()
        }

    private var wallpaper: Bitmap? = null
    private var layer = Layer.LETTERS
    private var shift = ShiftState.OFF
    private var lastShiftTap = 0L
    private var enterLabel: String? = null
    private var suggestions: List<String> = emptyList()

    private val density = resources.displayMetrics.density
    private var rowHpx = 0f
    private var stripHpx = 0f
    private var rowsTop = 0f

    private val keyRows = ArrayList<List<KeyRect>>()
    private val pointers = SparseArray<PointerState>()
    private val stripDown = SparseIntArray()

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dimPaint = Paint()
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 1f * density }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val srcRect = Rect()
    private val dstRect = Rect()
    private val tmpRect = RectF()

    init {
        computeMetrics()
    }

    // ---------------------------------------------------------------- API pública

    fun setWallpaper(bitmap: Bitmap?) {
        if (wallpaper !== bitmap) {
            wallpaper = bitmap
            invalidate()
        }
    }

    fun setLayer(newLayer: Layer) {
        if (layer == newLayer) return
        layer = newLayer
        layoutKeys()
        invalidate()
    }

    fun setSuggestions(list: List<String>) {
        if (suggestions != list) {
            suggestions = list
            invalidate()
        }
    }

    /** null = ícone de Enter; texto = rótulo da ação do campo (Ir, Buscar, Enviar...). */
    fun setEnterLabel(label: String?) {
        if (enterLabel != label) {
            enterLabel = label
            invalidate()
        }
    }

    fun resetShift() {
        shift = ShiftState.OFF
        invalidate()
    }

    /** Auto-maiúscula do editor. Não mexe se o Caps Lock estiver ligado. */
    fun autoShift(on: Boolean) {
        if (shift == ShiftState.CAPS) return
        val next = if (on) ShiftState.ONCE else ShiftState.OFF
        if (next != shift) {
            shift = next
            invalidate()
        }
    }

    // ---------------------------------------------------------------- medidas

    private fun dp(v: Float) = v * density

    private fun computeMetrics() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        rowHpx = dp(if (landscape) 42f else 52f)
        stripHpx = dp(if (landscape) 38f else 44f)
        rowsTop = stripHpx + dp(4f)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        computeMetrics()
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = (rowsTop + rowHpx * 4 + dp(8f)).toInt()
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutKeys()
    }

    private fun layoutKeys() {
        keyRows.clear()
        if (width == 0) return
        val rows = KeyboardLayouts.rows(layer)
        val padX = dp(3f)
        val gapX = dp(2.5f)
        val gapY = dp(3f)
        val avail = width - 2 * padX
        rows.forEachIndexed { r, row ->
            val total = row.fold(0f) { acc, k -> acc + k.weight }
            val unit = avail / total
            var x = padX
            val top = rowsTop + r * rowHpx
            val list = ArrayList<KeyRect>()
            for (key in row) {
                val w = key.weight * unit
                if (key.type != KeyType.SPACER) {
                    val cell = RectF(x, top, x + w, top + rowHpx)
                    val draw = RectF(x + gapX, top + gapY, x + w - gapX, top + rowHpx - gapY)
                    list.add(KeyRect(key, cell, draw))
                }
                x += w
            }
            keyRows.add(list)
        }
    }

    // ---------------------------------------------------------------- desenho

    override fun onDraw(canvas: Canvas) {
        drawBackground(canvas)
        drawStrip(canvas)
        for (row in keyRows) for (kr in row) drawKey(canvas, kr)
        drawOverlays(canvas)
    }

    private fun drawBackground(c: Canvas) {
        val wp = wallpaper
        if (wp == null || wp.isRecycled) {
            c.drawColor(COLOR_BG)
            return
        }
        val vw = width.toFloat()
        val vh = height.toFloat()
        val scale = max(vw / wp.width, vh / wp.height)
        val srcW = vw / scale
        val srcH = vh / scale
        val left = (wp.width - srcW) / 2f
        val top = (wp.height - srcH) * (style.focusY.coerceIn(0, 100) / 100f)
        val l = left.toInt().coerceIn(0, wp.width - 1)
        val t = top.toInt().coerceIn(0, wp.height - 1)
        val r = (left + srcW).toInt().coerceIn(l + 1, wp.width)
        val b = (top + srcH).toInt().coerceIn(t + 1, wp.height)
        srcRect.set(l, t, r, b)
        dstRect.set(0, 0, width, height)
        c.drawBitmap(wp, srcRect, dstRect, bgPaint)

        val a = style.dim.coerceIn(0, 90) * 255 / 100
        if (a > 0) {
            dimPaint.color = Color.argb(a, 0, 0, 0)
            c.drawRect(0f, 0f, vw, vh, dimPaint)
        }
    }

    private fun drawStrip(c: Canvas) {
        val h = stripHpx
        val s = h * 0.17f

        // botão ✦ (IA)
        if (isStripPressed(0)) {
            fillPaint.color = withAlpha(Color.WHITE, 36)
            tmpRect.set(dp(4f), dp(4f), h - dp(4f), h - dp(4f))
            c.drawRoundRect(tmpRect, dp(10f), dp(10f), fillPaint)
        }
        val cx = h / 2f
        val cy = h / 2f
        path.reset()
        path.moveTo(cx, cy - s * 1.9f)
        path.quadTo(cx, cy, cx + s * 1.9f, cy)
        path.quadTo(cx, cy, cx, cy + s * 1.9f)
        path.quadTo(cx, cy, cx - s * 1.9f, cy)
        path.quadTo(cx, cy, cx, cy - s * 1.9f)
        path.close()
        fillPaint.color = COLOR_ACCENT
        c.drawPath(path, fillPaint)

        // slots de sugestão
        val slotW = (width - h) / 3f
        linePaint.color = withAlpha(Color.WHITE, 45)
        for (k in 1..2) {
            val x = h + slotW * k
            c.drawLine(x, h * 0.28f, x, h * 0.72f, linePaint)
        }
        for (i in 0 until 3) {
            val word = suggestions.getOrNull(i) ?: continue
            val left = h + slotW * i
            if (isStripPressed(i + 1)) {
                fillPaint.color = withAlpha(Color.WHITE, 30)
                tmpRect.set(left + dp(3f), dp(4f), left + slotW - dp(3f), h - dp(4f))
                c.drawRoundRect(tmpRect, dp(10f), dp(10f), fillPaint)
            }
            textPaint.textSize = dp(16f)
            textPaint.typeface = if (i == 0) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            textPaint.color = if (i == 0) COLOR_FG else withAlpha(COLOR_FG, 225)
            val shown = TextUtils.ellipsize(word, textPaint, slotW - dp(12f), TextUtils.TruncateAt.END)
            val fm = textPaint.fontMetrics
            c.drawText(shown, 0, shown.length, left + slotW / 2f, h / 2f - (fm.ascent + fm.descent) / 2f, textPaint)
        }
    }

    private fun drawKey(c: Canvas, kr: KeyRect) {
        val key = kr.key
        val r = kr.draw
        val pressed = isPressed(kr)
        val baseAlpha = style.keyOpacity.coerceIn(0, 100) * 255 / 100
        val isEnter = key.type == KeyType.ENTER
        val isFunction = key.type != KeyType.CHAR && key.type != KeyType.SPACE && !isEnter

        fillPaint.color = when {
            isEnter -> if (pressed) COLOR_ACCENT_PRESSED else withAlpha(COLOR_ACCENT, 240)
            pressed -> withAlpha(COLOR_KEY_PRESSED, 245)
            isFunction -> withAlpha(COLOR_KEY_FN, baseAlpha)
            else -> withAlpha(COLOR_KEY, baseAlpha)
        }
        c.drawRoundRect(r, dp(8f), dp(8f), fillPaint)

        val cx = r.centerX()
        val cy = r.centerY()
        val fg = if (isEnter) COLOR_ACCENT_INK else COLOR_FG
        val s = rowHpx * 0.17f
        iconPaint.color = fg
        iconPaint.strokeWidth = dp(2f)

        when (key.type) {
            KeyType.CHAR -> {
                val size = if (layer == Layer.EMOJI) rowHpx * 0.5f else rowHpx * 0.42f
                drawCenteredText(c, displayText(key), cx, cy, size, fg)
                if (layer == Layer.LETTERS && key.hint != null) {
                    drawCenteredText(c, key.hint, r.right - dp(8f), r.top + dp(11f), dp(10f), withAlpha(COLOR_FG, 150))
                }
            }
            KeyType.SPACE -> drawCenteredText(c, "Tejando", cx, cy, rowHpx * 0.24f, withAlpha(COLOR_FG, 140))
            KeyType.SHIFT -> drawShiftIcon(c, cx, cy, s)
            KeyType.DELETE -> drawDeleteIcon(c, cx, cy, s)
            KeyType.ENTER -> {
                val label = enterLabel
                if (label != null) drawCenteredText(c, label, cx, cy, rowHpx * 0.27f, fg, bold = true)
                else drawEnterIcon(c, cx, cy, s)
            }
            KeyType.SWITCH_LAYER -> drawCenteredText(c, key.label, cx, cy, rowHpx * 0.30f, fg)
            KeyType.EMOJI_TOGGLE -> drawEmojiIcon(c, cx, cy, s * 1.15f)
            KeyType.SPACER -> Unit
        }
    }

    private fun drawOverlays(c: Canvas) {
        for (i in 0 until pointers.size()) {
            val ps = pointers.valueAt(i)
            val popup = ps.popup
            if (popup != null) {
                drawPopup(c, popup)
            } else if (!ps.consumed && ps.keyRect.key.type == KeyType.CHAR && layer != Layer.EMOJI) {
                drawBubble(c, ps.keyRect)
            }
        }
    }

    private fun drawBubble(c: Canvas, kr: KeyRect) {
        val cell = kr.cell
        val bw = cell.width() * 1.35f
        val bh = rowHpx * 1.05f
        val maxLeft = max(width - bw - dp(2f), dp(2f))
        val left = (cell.centerX() - bw / 2f).coerceIn(dp(2f), maxLeft)
        val top = max(dp(1f), kr.draw.top - bh - dp(4f))
        tmpRect.set(left, top, left + bw, top + bh)
        fillPaint.color = withAlpha(COLOR_KEY_LIGHT, 250)
        c.drawRoundRect(tmpRect, dp(10f), dp(10f), fillPaint)
        drawCenteredText(c, displayText(kr.key), tmpRect.centerX(), tmpRect.centerY(), rowHpx * 0.6f, COLOR_KEY_INK)
    }

    private fun drawPopup(c: Canvas, popup: Popup) {
        fillPaint.color = withAlpha(COLOR_KEY_LIGHT, 250)
        c.drawRoundRect(popup.rect, dp(10f), dp(10f), fillPaint)
        popup.items.forEachIndexed { i, item ->
            val l = popup.rect.left + i * popup.itemW
            val selected = i == popup.selected
            if (selected) {
                tmpRect.set(l + dp(3f), popup.rect.top + dp(3f), l + popup.itemW - dp(3f), popup.rect.bottom - dp(3f))
                fillPaint.color = COLOR_ACCENT
                c.drawRoundRect(tmpRect, dp(8f), dp(8f), fillPaint)
            }
            drawCenteredText(
                c, item, l + popup.itemW / 2f, popup.rect.centerY(), rowHpx * 0.46f,
                if (selected) COLOR_ACCENT_INK else COLOR_KEY_INK,
            )
        }
    }

    private fun drawCenteredText(
        c: Canvas, text: CharSequence, cx: Float, cy: Float, size: Float, color: Int, bold: Boolean = false,
    ) {
        textPaint.textSize = size
        textPaint.color = color
        textPaint.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        val fm = textPaint.fontMetrics
        c.drawText(text, 0, text.length, cx, cy - (fm.ascent + fm.descent) / 2f, textPaint)
    }

    private fun drawShiftIcon(c: Canvas, cx: Float, cy: Float, s: Float) {
        path.reset()
        path.moveTo(cx, cy - s)
        path.lineTo(cx + s, cy)
        path.lineTo(cx + s * 0.45f, cy)
        path.lineTo(cx + s * 0.45f, cy + s * 0.75f)
        path.lineTo(cx - s * 0.45f, cy + s * 0.75f)
        path.lineTo(cx - s * 0.45f, cy)
        path.lineTo(cx - s, cy)
        path.close()
        iconPaint.style = if (shift == ShiftState.OFF) Paint.Style.STROKE else Paint.Style.FILL_AND_STROKE
        c.drawPath(path, iconPaint)
        if (shift == ShiftState.CAPS) {
            iconPaint.style = Paint.Style.STROKE
            c.drawLine(cx - s * 0.45f, cy + s * 1.15f, cx + s * 0.45f, cy + s * 1.15f, iconPaint)
        }
        iconPaint.style = Paint.Style.STROKE
    }

    private fun drawDeleteIcon(c: Canvas, cx: Float, cy: Float, s: Float) {
        iconPaint.style = Paint.Style.STROKE
        path.reset()
        path.moveTo(cx - s, cy)
        path.lineTo(cx - s * 0.35f, cy - s * 0.7f)
        path.lineTo(cx + s, cy - s * 0.7f)
        path.lineTo(cx + s, cy + s * 0.7f)
        path.lineTo(cx - s * 0.35f, cy + s * 0.7f)
        path.close()
        c.drawPath(path, iconPaint)
        val k = s * 0.28f
        val mx = cx + s * 0.3f
        c.drawLine(mx - k, cy - k, mx + k, cy + k, iconPaint)
        c.drawLine(mx - k, cy + k, mx + k, cy - k, iconPaint)
    }

    private fun drawEnterIcon(c: Canvas, cx: Float, cy: Float, s: Float) {
        iconPaint.style = Paint.Style.STROKE
        path.reset()
        path.moveTo(cx + s * 0.8f, cy - s * 0.6f)
        path.lineTo(cx + s * 0.8f, cy)
        path.lineTo(cx - s * 0.8f, cy)
        c.drawPath(path, iconPaint)
        path.reset()
        path.moveTo(cx - s * 0.2f, cy - s * 0.55f)
        path.lineTo(cx - s * 0.8f, cy)
        path.lineTo(cx - s * 0.2f, cy + s * 0.55f)
        c.drawPath(path, iconPaint)
    }

    private fun drawEmojiIcon(c: Canvas, cx: Float, cy: Float, s: Float) {
        iconPaint.style = Paint.Style.STROKE
        c.drawCircle(cx, cy, s, iconPaint)
        iconPaint.style = Paint.Style.FILL
        c.drawCircle(cx - s * 0.35f, cy - s * 0.25f, s * 0.11f, iconPaint)
        c.drawCircle(cx + s * 0.35f, cy - s * 0.25f, s * 0.11f, iconPaint)
        iconPaint.style = Paint.Style.STROKE
        tmpRect.set(cx - s * 0.55f, cy - s * 0.45f, cx + s * 0.55f, cy + s * 0.6f)
        c.drawArc(tmpRect, 20f, 140f, false, iconPaint)
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    private fun displayText(key: Key): String =
        if (key.type == KeyType.CHAR && layer == Layer.LETTERS && shift != ShiftState.OFF) {
            key.label.uppercase()
        } else {
            key.label
        }

    // ---------------------------------------------------------------- toque

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = event.actionIndex
                handleDown(event.getPointerId(i), event.getX(i), event.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    handleMove(event.getPointerId(i), event.getX(i), event.getY(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = event.actionIndex
                handleUp(event.getPointerId(i), event.getX(i), event.getY(i))
            }
            MotionEvent.ACTION_CANCEL -> cancelAll()
        }
        return true
    }

    private fun handleDown(id: Int, x: Float, y: Float) {
        if (y < stripHpx) {
            stripDown.put(id, slotAt(x))
            invalidate()
            return
        }
        val kr = findKey(x, y) ?: return
        cancelPointer(id)
        val ps = PointerState(kr)
        pointers.put(id, ps)
        if (style.haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (kr.key.type == KeyType.DELETE) {
            listener?.onDelete()
            postDelayed(ps.repeat, LONG_PRESS_MS)
        } else {
            scheduleLongPress(ps)
        }
        invalidate()
    }

    private fun handleMove(id: Int, x: Float, y: Float) {
        val ps = pointers.get(id) ?: return
        val popup = ps.popup
        if (popup != null) {
            val idx = ((x - popup.rect.left) / popup.itemW).toInt().coerceIn(0, popup.items.size - 1)
            if (idx != popup.selected) {
                popup.selected = idx
                invalidate()
            }
            return
        }
        if (ps.consumed || ps.keyRect.key.type == KeyType.DELETE) return
        if (!ps.keyRect.cell.contains(x, y)) {
            val next = findKey(x, y)
            if (next != null && next !== ps.keyRect) {
                ps.keyRect = next
                scheduleLongPress(ps)
                invalidate()
            }
        }
    }

    private fun handleUp(id: Int, x: Float, y: Float) {
        val stripIndex = stripDown.indexOfKey(id)
        if (stripIndex >= 0) {
            val slot = stripDown.valueAt(stripIndex)
            stripDown.delete(id)
            if (y < stripHpx && slotAt(x) == slot) fireSlot(slot)
            invalidate()
            return
        }
        val ps = pointers.get(id) ?: return
        cancelPointer(id)
        val popup = ps.popup
        if (popup != null) {
            typeText(popup.items[popup.selected])
        } else if (!ps.consumed && !ps.repeating) {
            performKey(ps.keyRect.key)
        }
        invalidate()
    }

    private fun cancelPointer(id: Int) {
        val old = pointers.get(id) ?: return
        removeCallbacks(old.longPress)
        removeCallbacks(old.repeat)
        pointers.remove(id)
    }

    private fun cancelAll() {
        for (i in 0 until pointers.size()) {
            val ps = pointers.valueAt(i)
            removeCallbacks(ps.longPress)
            removeCallbacks(ps.repeat)
        }
        pointers.clear()
        stripDown.clear()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        cancelAll()
        super.onDetachedFromWindow()
    }

    private fun scheduleLongPress(ps: PointerState) {
        removeCallbacks(ps.longPress)
        val key = ps.keyRect.key
        val wantsLongPress = key.type == KeyType.SPACE ||
            key.type == KeyType.EMOJI_TOGGLE ||
            (key.type == KeyType.CHAR && key.popupItems.isNotEmpty())
        if (wantsLongPress) postDelayed(ps.longPress, LONG_PRESS_MS)
    }

    private fun onLongPress(ps: PointerState) {
        val key = ps.keyRect.key
        when (key.type) {
            KeyType.SPACE, KeyType.EMOJI_TOGGLE -> {
                ps.consumed = true
                if (style.haptic) performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                listener?.onInputMethodPicker()
            }
            KeyType.CHAR -> openPopup(ps)
            else -> Unit
        }
    }

    private fun openPopup(ps: PointerState) {
        val key = ps.keyRect.key
        var items = key.popupItems
        if (items.isEmpty()) return
        if (layer == Layer.LETTERS && shift != ShiftState.OFF) items = items.map { it.uppercase() }

        val cell = ps.keyRect.cell
        val itemW = max(cell.width(), dp(40f))
        val total = itemW * items.size
        val margin = dp(2f)
        val leftAligned = cell.left + total <= width - margin
        val left: Float
        val display: List<String>
        if (leftAligned) {
            left = cell.left
            display = items
        } else {
            left = max(margin, cell.right - total)
            display = items.reversed()
        }
        val h = rowHpx * 0.95f
        val top = max(dp(2f), cell.top - h - dp(6f))
        val rect = RectF(left, top, left + total, top + h)
        val selected = ((cell.centerX() - left) / itemW).toInt().coerceIn(0, display.size - 1)
        ps.popup = Popup(display, rect, itemW, selected)
        if (style.haptic) performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        invalidate()
    }

    // ---------------------------------------------------------------- ações

    private fun performKey(key: Key) {
        when (key.type) {
            KeyType.CHAR -> typeText(displayText(key))
            KeyType.SPACE -> typeText(" ")
            KeyType.ENTER -> listener?.onEnter()
            KeyType.SHIFT -> toggleShift()
            KeyType.SWITCH_LAYER, KeyType.EMOJI_TOGGLE -> key.targetLayer?.let { setLayer(it) }
            KeyType.DELETE, KeyType.SPACER -> Unit
        }
    }

    private fun typeText(text: String) {
        if (shift == ShiftState.ONCE) {
            shift = ShiftState.OFF
            invalidate()
        }
        listener?.onText(text)
    }

    private fun toggleShift() {
        val now = SystemClock.uptimeMillis()
        shift = when {
            shift == ShiftState.CAPS -> ShiftState.OFF
            shift == ShiftState.ONCE && now - lastShiftTap < DOUBLE_TAP_MS -> ShiftState.CAPS
            shift == ShiftState.ONCE -> ShiftState.OFF
            else -> ShiftState.ONCE
        }
        lastShiftTap = now
        invalidate()
    }

    // ---------------------------------------------------------------- busca de teclas

    private fun findKey(x: Float, y: Float): KeyRect? {
        if (keyRows.isEmpty()) return null
        val r = ((y - rowsTop) / rowHpx).toInt().coerceIn(0, keyRows.size - 1)
        var best: KeyRect? = null
        var bestDist = Float.MAX_VALUE
        for (kr in keyRows[r]) {
            val d = when {
                x < kr.cell.left -> kr.cell.left - x
                x > kr.cell.right -> x - kr.cell.right
                else -> 0f
            }
            if (d < bestDist) {
                bestDist = d
                best = kr
            }
        }
        return best
    }

    private fun isPressed(kr: KeyRect): Boolean {
        for (i in 0 until pointers.size()) if (pointers.valueAt(i).keyRect === kr) return true
        return false
    }

    private fun isStripPressed(slot: Int): Boolean {
        for (i in 0 until stripDown.size()) if (stripDown.valueAt(i) == slot) return true
        return false
    }

    /** 0 = botão ✦, 1..3 = sugestões. */
    private fun slotAt(x: Float): Int {
        if (x < stripHpx) return 0
        val slotW = (width - stripHpx) / 3f
        return 1 + ((x - stripHpx) / slotW).toInt().coerceIn(0, 2)
    }

    private fun fireSlot(slot: Int) {
        if (slot == 0) {
            listener?.onAiClicked()
        } else {
            suggestions.getOrNull(slot - 1)?.let { listener?.onSuggestionPicked(it) }
        }
    }

    private companion object {
        const val LONG_PRESS_MS = 380L
        const val REPEAT_INTERVAL_MS = 45L
        const val DOUBLE_TAP_MS = 350L

        // Paleta herdada do projeto de referência (tons quentes + laranja).
        val COLOR_BG = 0xFF14120E.toInt()
        val COLOR_KEY = 0xFF1E1B16.toInt()
        val COLOR_KEY_FN = 0xFF3A342B.toInt()
        val COLOR_KEY_PRESSED = 0xFF5A5144.toInt()
        val COLOR_KEY_LIGHT = 0xFFF3ECDF.toInt()
        val COLOR_KEY_INK = 0xFF1C1814.toInt()
        val COLOR_FG = 0xFFF4EFE6.toInt()
        val COLOR_ACCENT = 0xFFE8893A.toInt()
        val COLOR_ACCENT_PRESSED = 0xFFF2A667.toInt()
        val COLOR_ACCENT_INK = 0xFF1A1008.toInt()
    }
}
