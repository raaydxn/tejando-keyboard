package com.tejando.keyboard.engine

import android.content.Context
import com.tejando.keyboard.R
import java.text.Normalizer

/**
 * Sugestões simples por prefixo, usando a lista de palavras em res/raw/palavras_pt.txt
 * (uma por linha, da mais comum para a menos comum). Ignora acentos ao comparar:
 * digitar "voce" sugere "você".
 */
class LocalSuggestionEngine(private val context: Context) : SuggestionEngine {

    private val words: List<String> by lazy {
        context.resources.openRawResource(R.raw.palavras_pt)
            .bufferedReader(Charsets.UTF_8)
            .useLines { lines -> lines.map { it.trim() }.filter { it.isNotEmpty() }.toList() }
    }

    private val folded: List<String> by lazy { words.map { fold(it) } }

    override fun suggest(textBeforeCursor: String, max: Int): List<String> {
        val prefix = currentWordPrefix(textBeforeCursor)
        if (prefix.isEmpty()) {
            return if (textBeforeCursor.isBlank()) STARTERS.take(max) else emptyList()
        }
        val key = fold(prefix)
        val out = ArrayList<String>(max)
        for (i in words.indices) {
            val f = folded[i]
            if (f.length > key.length && f.startsWith(key)) {
                out.add(matchCase(prefix, words[i]))
                if (out.size >= max) break
            }
        }
        return out
    }

    private fun fold(s: String): String =
        MARKS.replace(Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD), "")

    private fun matchCase(typed: String, word: String): String = when {
        typed.length > 1 && typed.all { it.isUpperCase() } -> word.uppercase()
        typed.first().isUpperCase() -> word.replaceFirstChar { it.uppercase() }
        else -> word
    }

    private companion object {
        val MARKS = Regex("\\p{M}+")
        val STARTERS = listOf("Oi", "Olá", "Tudo bem?")
    }
}
